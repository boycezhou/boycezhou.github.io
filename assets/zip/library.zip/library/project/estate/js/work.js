// ----------------------------搜索框模块 START-------------------------
// 非直接输入时 锁定/true, 非直接输入点完成false
var inputLock = false;
// 点击搜索按钮
$('.followContent .searchBox .searchBtn').on('tap', function(event) {
    event.stopPropagation();
    $('.followContent .searchBox input').trigger('blur');
});
// 按下enter, 搜索, 换行键
$('.followContent .searchBox input').on('keyup', function(e) {
    e.preventDefault();
    var keycode = e.keyCode;
    if (keycode == '13') {
        $(this).trigger('blur');
        return;
    }
});
// 有些键盘, 例 '完成', 触发不了keyup事件, 但会使input失去焦点
$('.followContent .searchBox input').on('blur', function() {
    var val = $(this).val().trim();
    searchData(infoList, infoList_search, val);
    renderInfoList(infoList_search);
});
// 非直接输入开始
$('.followContent .searchBox input').on('compositionstart', function() {
    inputLock = true;
});
// 非直接输入开始
$('.followContent .searchBox input').on('compositionend', function() {
    inputLock = false;
    var val = $(this).val().trim();
    searchData(infoList, infoList_search, val);
    renderInfoList(infoList_search);
});
// 输入中文时, 会触发input(不会触发keyup)
$('.followContent .searchBox input').on('input', function(e) {
    e.preventDefault();
    var val = $(this).val().trim();
    if (!inputLock) {
        searchData(infoList, infoList_search, val);
        renderInfoList(infoList_search);
    }
});
/* 
 * @function 搜索客户
 * @params {srcData: Array} 源数据
 * @params {targetData: Array} 复合搜索条件的数据
 * @params {val: String} 搜索条件
 */
function searchData(srcData, targetData, val) {
    console.log('srcData', srcData);
    console.log('targetData', targetData);
    targetData.length = 0;
    for (var i = 0; i < srcData.length; i++) {
        if (srcData[i].telephone.indexOf(val) != -1 || srcData[i].name.indexOf(val) != -1 || val == '') {
            targetData.push(srcData[i]);
        }
    }
}
// ----------------------------搜索框模块 END---------------------------

// ----------------------------表单提示模块 START-------------------------
/* 
<div class="inputBox">
    <label for="telephone">手机号码</label>
    <input id="telephone" type="number" pattern="[0-9]*" placeholder="输入您的手机号码">
    <div class="warning2">请输入正确的手机号!</div>
</div>
*/
telephoneEvent2();
$('.submit').on('click', function(event) {
    event.preventDefault();
    if (telephoneTest2() && passwordTest2()) {
        adviserLogin();
    }
});
// ----------------------------表单提示模块 END---------------------------

// ----------------------------选择框模块 START-------------------------
/*
<div class="subName_popularize name_second_table selectBox">
<div class="infoBox clearfix changeBox">
    <div class="inputBox">
        <div class="select mainBg" onselectstart="return false">添加类目</div>
        <div class="triangle"></div>
        <div class="optionBox" data-kpl="推广" data-kplen="extension">
            <ul>
                <li data-name="报纸">报纸</li>
                <li data-name="户外广告">户外广告</li>
                <li data-name="杂志">杂志</li>
                <li data-name="电视">电视</li>
                <li data-name="电台">电台</li>
                <li data-name="短信">短信</li>
                <li data-name="网络">网络</li>
                <li data-name="临时广告位">临时广告位</li>
                <li data-name="媒体公关费用">媒体公关费用</li>
        </div>
    </div>
</div>
</div>
.changeBox {
    height: 32px;
    .inputBox {
        width: 180px;
        height: 32px;
        // background-color: #c6c6c6;
        position: relative;
        border: 1px solid #209aff;
        cursor: pointer;
        .select {
            line-height: 32px;
            position: absolute;
            left: 0;
            top: 0;
            width: 160px;
            height: 100%;
            text-align: center;
            color: #777;
            // color: #fff;
        }
        .triangle {
            position: absolute;
            right: 15px;
            top: 11px;
            width: 0;
            height: 0;
            border-top: 12px solid #209aff;
            border-right: 8px solid transparent;
            border-bottom: 12px solid transparent;
            border-left: 8px solid transparent;
            &.active {
                top: -2px;
                border-top: 12px solid transparent;
                border-right: 8px solid transparent;
                border-bottom: 12px solid #209aff;
                border-left: 8px solid transparent;
            }
        }
        .optionBox {
            position: absolute;
            left: -1px;
            top: 37px;
            z-index: 2;
            width: 100%;
            border: 1px solid #209aff;
            display: none;
            max-height: 160px;
            overflow-y: auto;
            overflow-x: hidden;
            &::-webkit-scrollbar {
                width: 3px;
            }
            &::-webkit-scrollbar-thumb {
                background-color: #ccc;
                border-radius: 6px;
            }
            &::-webkit-scrollbar-track {
                background-color: #fff;
            }
            &.active {
                display: block;
            }
            ul {
                width: 100%;
                li {
                    width: 100%;
                    height: 32px;
                    line-height: 32px;
                    // border: 1px solid #c6c6c6;
                    background-color: #fff;
                    text-align: center;
                    &:hover {
                        background-color: #209aff;
                        color: #fff;
                    }
                }
            }
        }
    }
}
  */
// 点击选择框三角形
$('.selectBox .triangle').on('click', function(event) {
    event.stopPropagation();
    var $this = $(this);
    $('.selectBox .triangle.active').not(this).trigger('click');
    if ($this.hasClass('active')) {
        $this.removeClass('active');
        $this.next('.optionBox').removeClass('active');
    } else {
        $this.addClass('active');
        $this.next('.optionBox').addClass('active');
    }
});
// 点击选择框选择, 与点击三角型一样
$('.selectBox .select').on('click', function(event) {
    event.stopPropagation();
    var $this = $(this);
    $this.next('.triangle').trigger('click');
});
// 点击选择框选项
$('.selectBox .optionBox ul').on('click', 'li', function(event) {
    event.stopPropagation();
    var $this = $(this);
});
// 销售物料, 删除本行
$('body').on('click', function() {
    if ($('.selectBox .optionBox').hasClass('active')) {
        $('.selectBox .triangle.active').trigger('click');
    }
});
// ----------------------------选择框模块 END---------------------------

// ----------------------------计算银行利率模块 START-------------------------
var rateData = {};
/* 
 * @function 计算月供贷款额
 * @params {option: Object} 可选项
 * @params {option.price: Object} 本金
 * @params {option.month: Object} 贷款月数
 */
function calcLoanPrice(option) {
    var price = option.price || houseData.mortgagePrice;
    var month = option.month;
    var year = month / 12;
    // var monthRate = 0.049 / 12;
    var monthRate = rateData[year] / 12;
    var pay = (monthRate * Math.pow(1 + monthRate, month) * price) / (Math.pow(1 + monthRate, month) - 1);
    var monthPay = parseInt(pay);
    return isNaN(monthPay) ? '' : monthPay;
}
/* 
 * @function 按需渲染一次性付款, 按揭付款
 * @params {data: Object} 户型数据
 */
function renderHouseData(data) {
    $('.houseImgBox img').attr('src', data.imgSrc);
    $('#ban').html(data.ban);
    $('#cell').html(data.cell);
    $('#number').html(data.number);
    $('#builtArea').html(data.builtArea);
    $('#innerArea').html(data.innerArea);
    $('#singlePrice').html(addDot(data.singlePrice));
    $('#totalPrice').html(addDot(data.totalPrice));
    $('#fixedPrice').html(addDot(data.fixedPrice));
    switch (data.payWay) {
        case 1:
            $('.mortgageBox').hide();
            $('.mortgageInfoBox').hide();
            $('#discount_single').html(data.discount_single * 100);
            $('#allPrice_single').html(addDot(data.allPrice_single));
            $('#singlePrice_single').html(addDot(data.singlePrice_single));
            break;
        case 2:
            $('.singleBox').hide();
            $('#discount_mortgage').html(data.discount_mortgage * 100);
            $('#allPrice_mortgage').html(addDot(data.allPrice_mortgage));
            $('#singlePrice_mortgage').html(addDot(data.singlePrice_mortgage));
            $('#firstPay').html(data.firstPay);
            $('#price_firstPay').html(addDot(data.price_firstPay));
            $('#mortgagePay').html(data.mortgagePay);
            $('#price_mortgagePay').html(addDot(data.price_mortgagePay));
            $('#loanYear01').html(data.loanYear01);
            $('#monthPay01').html(addDot(data.monthPay01));
            $('#loanYear02').html(data.loanYear02);
            $('#monthPay02').html(addDot(data.monthPay02));
            break;
    }
}
// ----------------------------计算银行利率模块 END---------------------------

// ----------------------------定位模块 START-------------------------
/* 
<script type="text/javascript" src="http://webapi.amap.com/maps?v=1.4.4&key=96f96fea80b3e2ce0b30252200c11232"></script>
*/
var addressObj = {
    province: '',
    city: '',
    district: '',
    township: '',
    street: '',
    streetNumber: '',
    neighborhood: '',
    neighborhoodType: '',
    formattedAddress: '',
    location_type: '',
};
/* 
 * @function 获取定位地址
 */
function getLocation() {
    function onComplete(res) {
        console.log('res', res);
        addressObj.province = res.addressComponent.province;
        addressObj.city = res.addressComponent.city;
        addressObj.district = res.addressComponent.district;
        addressObj.township = res.addressComponent.township;
        addressObj.street = res.addressComponent.street;
        addressObj.streetNumber = res.addressComponent.streetNumber;
        addressObj.neighborhood = res.addressComponent.neighborhood;
        addressObj.neighborhoodType = res.addressComponent.neighborhoodType;
        addressObj.formattedAddress = res.formattedAddress;
        addressObj.location_type = res.location_type;


        provinceObj.name = addressObj.province;
        cityObj.name = addressObj.city;
        districtObj.name = addressObj.district;

        address = res.formattedAddress.split(res.addressComponent.district + res.addressComponent.township)[1];
        // address = res.addressComponent.neighborhood;
        // var address = res.addressComponent.street + res.addressComponent.streetNumber + res.formattedAddress.split(res.addressComponent.township)[1];
        $('#location').val(address);
        $('#location_city').html(provinceObj.name + '/' + cityObj.name + '/' + districtObj.name);
        // alert(res.formattedAddress);
    }

    function onError(res) {
        console.log('Error-res', res);
    }
    mapObj = new AMap.Map('container');
    mapObj.plugin('AMap.Geolocation', function() {
        geolocation = new AMap.Geolocation({
            enableHighAccuracy: true, //是否使用高精度定位，默认:true
            timeout: 10000, //超过10秒后停止定位，默认：无穷大
            maximumAge: 0, //定位结果缓存0毫秒，默认：0
            convert: true, //自动偏移坐标，偏移后的坐标为高德坐标，默认：true
            showButton: true, //显示定位按钮，默认：true
            buttonPosition: 'LB', //定位按钮停靠位置，默认：'LB'，左下角
            buttonOffset: new AMap.Pixel(10, 20), //定位按钮与设置的停靠位置的偏移量，默认：Pixel(10, 20)
            showMarker: true, //定位成功后在定位到的位置显示点标记，默认：true
            showCircle: true, //定位成功后用圆圈表示定位精度范围，默认：true
            panToLocation: true, //定位成功后将定位到的位置作为地图中心点，默认：true
            zoomToAccuracy: true //定位成功后调整地图视野范围使定位位置及精度范围视野内可见，默认：false
        });
        // mapObj.addControl(geolocation);
        geolocation.getCurrentPosition();
        AMap.event.addListener(geolocation, 'complete', onComplete); //返回定位信息
        AMap.event.addListener(geolocation, 'error', onError); //返回定位出错信息
    });
}
// ----------------------------定位模块 END---------------------------

// ----------------------------搜索模块 START-------------------------
/* 
 * @function 搜索客户
 * @params {srcData: Array} 源数据
 * @params {targetData: Array} 复合搜索条件的数据
 * @params {val: String} 搜索条件
 */
function searchData(srcData, targetData, val) {
    console.log('srcData', srcData);
    console.log('targetData', targetData);
    targetData.length = 0;
    for (var i = 0; i < srcData.length; i++) {
        if (srcData[i].telephone.indexOf(val) != -1 || srcData[i].name.indexOf(val) != -1 || val == '') {
            targetData.push(srcData[i]);
        }
    }
}
// ----------------------------搜索模块 END---------------------------

// ----------------------------图片上传模块 START-------------------------
/* 
// -------html-------
<input id="imgFile" type="file" name="upfile" multiple accept="image/png, image/jpeg, image/gif, image/jpg" style="display:none" />
 */
// -------js--------
upload({
    url: '/wap/Broker/modifyInfo',
    imgId: $('.ID').data('id'),
    password: passwordVal,
    upfile: upfile,
    callback: function() {
        toastModel('设置成功...', function() {
            window.location.href = '/wap/broker/clientManage';
        });
    }
});
/* 
 * @function 上传照片(没有兼容性)
 */
function upload(option) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", option.url);
    xhr.overrideMimeType('text/plain; charset=x-user-defined-binary');
    // xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            if (typeof option.callback == 'function') {
                option.callback();
            }
        }
    };
    var fd = new FormData();
    fd.append('upfile', option.upfile);
    fd.append('id', option.imgId);
    fd.append('password', option.password);
    xhr.send(fd);
}
/*
 * @function 预览照片
 * @params {fileDom: DOM} input:type=file
 */
function imgPreview(fileDom) {
    var reader = new FileReader();
    //获取文件
    var file = fileDom.files[0];
    //读取完成
    reader.onload = function(e) {
        //获取图片dom
        var img = document.getElementsByClassName("portrait")[0];
        //图片路径设置为读取的图片
        img.src = e.target.result;
        result = e.target.result
    };
    reader.readAsDataURL(file);
}
// ----------------------------图片上传模块 END---------------------------

// ----------------------------信息提示框模块 START-------------------------
/*
// -----html-----
<div id="toastModel"></div>
// -----css-----
#toastModel {
    // position: absolute;
    position: fixed;
    left: 50%;
    top: 50%;
    z-index: 10;
    margin-left: r(-220);
    margin-top: r(-75);
    // background-color: pink;
    background-color: #fff;
    width: r(440);
    height: r(150);
    border-radius: r(10);
    color: #777;
    font-size: r(40);
    box-shadow: 0 0 r(30) 0 rgba(0, 0, 0, 0.7);
    display: none;
    line-height: r(150);
    text-align: center;
}
  */
// -----js-----
/*
 * @function 提示框
 */
function toastModel(content, callback) {
    $('#toastModel').html(content).show();
    setTimeout(function() {
        $('#toastModel').fadeOut(500);
        setTimeout(function() {
            if (typeof callback == 'function') {
                callback();
            }
        }, 500);
    }, 1000);
}
// ----------------------------信息提示框模块 END---------------------------

// ----------------------------网页转图片模块 START-------------------------
/*
<script src="__WAP__/js/public/html2canvas.js"></script>
  */
function toImg() {
    var w = $("#layout").width();
    var h = $("#layout").height(); //要将 canvas 的宽高设置成容器宽高的 2 倍  
    html2canvas($("#layout").get(0)).then(function(canvas) {
        var dataUrl = canvas.toDataURL();
        $('<img style="width:100%"/>').attr('src', dataUrl).appendTo($('body'));
        $("#layout").hide();
        $('.btn').hide();
    });
}
// ----------------------------网页转图片模块 END---------------------------

// ----------------------------跳转链接时记入状态, 自动切换tab START-------------------------
function jumpToNew() {
    var link = window.localStorage.getItem('link_broker');
    if (link == 'new') {
        console.log('111');
        $('.tabBox .newFollow').trigger('tap');
        window.localStorage.setItem('link_broker', '');
    }
}
// ----------------------------跳转链接时记入状态, 自动切换tab START-------------------------

// ----------------------------数据转换文字信息 START-------------------------
/* 
 * @function 状态数据转文字信息
 * @params {status: Number} 状态数据
 */
function statusToStr(status) {
    switch (+status) {
        case 0:
            return '首次来电';
            break;
        case 1:
            return '来电';
            break;
        case 2:
            return '首次来访';
            break;
        case 3:
            return '复访';
            break;
        case 4:
            return '验资';
            break;
    }
}
// ----------------------------数据转换文字信息 START-------------------------

// ----------------------------百分比环形图 START-------------------------
/* 
    // html结构
    <div class="canvasBox">
        <canvas id="canvas_deal"></canvas>
    </div>
*/
var circleAnimateFlag = true;
/* 
 * @funtion 清除canvas, 当绘制环形图开启动画时, 需要此种替换标签, 若不需要动画, 可换成设置width, height属性
 */
function clearCanvas() {
    $('.allSell .dealPercent .canvasBox').html('<canvas id="canvas_deal" width="' + canvasWid + '" height="' + canvasHei + '"></canvas>');
    $('.allSell .averageDiscount .canvasBox').html('<canvas id="canvas_average" width="' + canvasWid + '" height="' + canvasHei + '"></canvas>');
    $('.online .dealPercent .canvasBox').html('<canvas id="canvas_onlineDeal" width="' + canvasWid + '" height="' + canvasHei + '"></canvas>');
    $('.online .arrivePercent .canvasBox').html('<canvas id="canvas_arrive" width="' + canvasWid + '" height="' + canvasHei + '"></canvas>');
}
/* 
 * @funtion 绘制所有环形百分率
 */
function drawCircle_all() {
    var lineWid = size(10);
    drawCircle({
        id: 'canvas_deal',
        angle: 0.3
    });
    drawCircle({
        id: 'canvas_average',
        angle: 0.1
    });
    drawCircle({
        id: 'canvas_onlineDeal',
        angle: 0.35
    });
    drawCircle({
        id: 'canvas_arrive',
        angle: 0.6
    });
}
/* 
 * @funtion 绘制环形百分率
 */
function drawCircle(_options) {
    var lineWid = size(10);;
    var fontSize = size(30);;
    var options = _options || {}; //获取或定义options对象;
    options.angle = options.angle; //定义默认角度1为360度(角度范围 0-1);
    options.color = options.color || '#1695ff'; //定义默认颜色（包括字体和边框颜色）;
    options.lineWidth = options.lineWidth || lineWid; //定义默认圆描边的宽度;
    options.lineCap = options.lineCap || 'round'; //定义描边的样式，默认为直角边，round 为圆角
    // options.animateFlag = options.animateFlag == undefined ? true : options.animateFlag;
    // options.lineCap = options.lineCap || 'square'; //定义描边的样式，默认为直角边，round 为圆角
    var text_circle = parseInt(options.angle * 100) + '%';
    // var text_circle = parseInt(options.angle * 100) + '%';
    var oBoxOne = document.getElementById(options.id);
    var sCenter = oBoxOne.width / 2; //获取canvas元素的中心点;
    var ctx = oBoxOne.getContext('2d');

    // var nBegin = Math.PI; //定义起始角度;
    // var nEnd = Math.PI * 2; //定义结束角度;
    var nBegin = Math.PI / 2; //定义起始角度;
    var nEnd = Math.PI * 2; //定义结束角度;
    // var grd = ctx.createLinearGradient(0, 0, oBoxOne.width, 0); //grd定义为描边渐变样式;
    // grd.addColorStop(0, 'red');
    // grd.addColorStop(0.5, 'yellow');
    // grd.addColorStop(1, 'green');

    ctx.textAlign = 'center'; //定义字体居中;
    ctx.textBaseline = "middle";
    ctx.font = 'normal normal ' + fontSize + 'px Arial'; //定义字体加粗大小字体样式;
    // ctx.fillStyle = options.color == 'grd' ? grd : options.color; //判断文字填充样式为颜色，还是渐变色;
    ctx.fillStyle = '#777';
    ctx.fillText(text_circle, sCenter, sCenter); //设置填充文字;
    /*ctx.strokeStyle = grd;    //设置描边样式为渐变色;
    ctx.strokeText((options.angle * 100) + '%', sCenter, sCenter);    //设置描边文字(即镂空文字);*/
    ctx.lineCap = options.lineCap;
    ctx.strokeStyle = options.color;
    // ctx.strokeStyle = options.color == 'grd' ? grd : options.color;
    ctx.lineWidth = options.lineWidth;

    ctx.beginPath(); //设置起始路径，这段绘制360度背景;
    ctx.strokeStyle = '#e2e2e2';
    ctx.arc(sCenter, sCenter, (sCenter - options.lineWidth), -nBegin, nEnd, false);
    ctx.stroke();

    var imd = ctx.getImageData(0, 0, 240, 240);

    function draw(current) { //该函数实现角度绘制;
        ctx.putImageData(imd, 0, 0);
        ctx.beginPath();
        // ctx.strokeStyle = options.color == 'grd' ? grd : options.color;
        ctx.strokeStyle = options.color;
        ctx.arc(sCenter, sCenter, (sCenter - options.lineWidth), -nBegin, (nEnd * current) - nBegin, false);
        ctx.stroke();
    }

    var t = 0;
    var timer = null;

    function loadCanvas(angle) { //该函数循环绘制指定角度，实现加载动画;
        if (circleAnimateFlag) {
            timer = setInterval(function() {
                if (t > angle) {
                    draw(options.angle);
                    clearInterval(timer);
                } else {
                    draw(t);
                    t += 0.02;
                }
            }, 20);
        } else {
            draw(options.angle);
        }
    }
    loadCanvas(options.angle); //载入百度比角度  0-1 范围;
    timer = null;
}
// ----------------------------百分比环形图 END-------------------------

/*
 * @function: 各页面切换动画
 * @params {showPageSelector: String} : 将要显示页面选择器
 * @params {hidePageSelector: String} : 将要消失页面选择器
 * @params {callback: Function} : 动画完毕后的回调函数
 */
function changePage(showPageSelector, hidePageSelector, callback) {
    $(showPageSelector)
        .css({
            opacity: 1,
            zIndex: 1
        })
        .animate({
            left: 0
        }, 2000);
    $(hidePageSelector)
        .css({
            zIndex: 0
        })
        .addClass('scaleEnd boxShadow')
        .animate({
            opacity: 0
        }, 2000, function() {
            $(hidePageSelector).css({
                left: '100%',
                transform: 'scale(1,1)'
            }).removeClass('scaleEnd boxShadow');
            if (typeof callback === 'function') {
                callback();
            }
        })
}
/*
 * @function 后台返回所有数据, 前端分页渲染
 */
function toggleGoods() {
    /*
     * @function 切换商品
     * @params {option: Object} 参数选项
     * @params {option.pageIndex: Number} 切换页码(不传值默认切换第一页)
     * @params {option.data: Array} 商品数据
     */
    function changeGoods(option) {
        var pageSize = 6;
        var pageIndex = option.pageIndex || 1;
        var dataArr = [];
        dataArr = option.data.slice((pageIndex - 1) * pageSize, pageIndex * pageSize);
        var goodListHtml = template('finalBabyinfo_goodList', {
            goods: dataArr
        });
        $('.final-babyinfo .good-list').html(goodListHtml);
        btnFlag = false;
    }

    // 点击事件切换产品
    var btnFlag = false; // 点击切换产品截流 ( 只有当前渲染完毕, 点击切换产品才能继续切换 )
    var goodsPageIndex = 1; // 商品页码
    $('.final-babyinfo .mother-change .btn').on('click', function() {
        if (btnFlag) {
            console.log('btn');
            return;
        }
        btnFlag = true;
        var pageTotal = Math.ceil(motherBabyGoodsData.length / 6);
        goodsPageIndex++;
        if (goodsPageIndex > pageTotal) {
            goodsPageIndex = 1;
        }
        changeGoods({
            data: motherBabyGoodsData,
            pageIndex: goodsPageIndex
        });
    });
}
/* 
 * @function 随机设置背景颜色
 */
function setBgc_random() {
    var remainder = 0;
    for (var i = 0; i < 38; i++) {
        remainder = (i + 1) % 8;
        if (remainder == 1 || remainder == 3 || remainder == 6 || remainder == 0) {
            $('.productList li').eq(i).css('background-color', '#d5ecff');
        }
    }
}
/* 
 * @function 屏幕的宽度和高度
 */
function getScreenHeiAndWid() {
    // 网页可见区域宽： document.body.clientWidth
    // 网页可见区域高： document.body.clientHeight
    // 网页可见区域宽： document.body.offsetWidth (包括边线的宽)
    // 网页可见区域高： document.body.offsetHeight (包括边线的高)
    // 网页正文全文宽： document.body.scrollWidth
    // 网页正文全文高： document.body.scrollHeight
    // 网页被卷去的高： document.body.scrollTop
    // 网页被卷去的左： document.body.scrollLeft
    // 网页正文部分上： window.screenTop
    // 网页正文部分左： window.screenLeft
    // 屏幕分辨率的高： window.screen.height
    // 屏幕分辨率的宽： window.screen.width
    // 屏幕可用工作区高度： window.screen.availHeight
    // 屏幕可用工作区宽度： window.screen.availWidth
    $(window).height(); //浏览器当前窗口可视区域高度
    $(document).height(); //浏览器当前窗口文档的高度
    $(document.body).height(); //浏览器当前窗口文档body的高度
    $(document.body).outerHeight(true); //浏览器当前窗口文档body的总高度 包括border padding margin
    $(window).width(); //浏览器当前窗口可视区域宽度
    $(document).width(); //浏览器当前窗口文档对象宽度
    $(document.body).width(); //浏览器当前窗口文档body的宽度
    $(document.body).outerWidth(true); //浏览器当前窗口文档body的总宽度 包括border padding margin
}

// ----------------------------百度地图 START-------------------------
/* 
 * @function 根据经纬度获取位置
 */
function baiduMap() {
    // html: <script id="map"></script>
    // 全局属性
    var address = '';
    // 全局方法
    function renderReverse(res) {
        address = res.result.addressComponent.city + res.result.addressComponent.district + res.result.addressComponent.street;
        $('#location').val(address);
        // $('#map').attr('src', '');
    }
    // 点击定位, 将位置信息输入input框 ( 未知: 只能定位一次 )
    $('.locationIcon').on('click', function() {
        if (address) {
            $('#location').val(address);
            return;
        }
        window.navigator.geolocation.getCurrentPosition(function(position) {
            var longitude = position.coords.longitude;
            var latitude = position.coords.latitude;
            $('#map').attr('src', 'http://api.map.baidu.com/geocoder/v2/?callback=renderReverse&location=' + latitude + ',' + longitude + '&output=json&pois=1&ak=xpj57sqezKgoKCGNT1uXs1sbtKeGjygw');
        });
    });
}
/* 
<div id="container_map" class="mapBox"></div>
<script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=xpj57sqezKgoKCGNT1uXs1sbtKeGjygw"></script>
 */
var mapObj = null;
/* 
 * @function 地图
 */
function map(data) {
    var longitude = 114.055353;
    var latitude = 22.562075;
    var myIconSize = '16px';
    var json = mapJson;
    var map = new BMap.Map("container_map");
    // 创建地图实例  
    var point = new BMap.Point(longitude, latitude);
    // 创建点坐标  
    map.centerAndZoom(point, 11);

    map.setMapStyle({
        styleJson: json
    });
    //禁止拖拽
    // map.disableDragging();
    // 开启鼠标缩放
    map.enableScrollWheelZoom(true);
    mapObj = map;

}
/* 
 * @function 绘制覆盖物
 */
function drawMap(map, data) {
    var pointList = [];
    var CircleAniLen = 48;
    var CircleColor = 'rgba(197,125,160,0.8)';
    var dealLen = 8;
    var visitColor = '#ffd900';
    var forwardColor = '#08f2c9';
    var receiveColor = '#127cdf';
    var lineColor = '#ff5722';
    var lineWeight = 1;
    var lineOpacity = 1;
    var arrowLen = 8;
    var point = null;
    var point2 = null;
    var polyline = null;

    for (var i = 0; i < data.customervisitData.length; i++) {
        point = new BMap.Point(data.customervisitData[i].longitude, data.customervisitData[i].latitude);
        map.addOverlay(addEvent(new BMap.Marker(point, {
            icon: myIcon3
        }), {
            text: data.customervisitData[i].nickname,
            imgUrl: data.customervisitData[i].headimgurl,
        }));
        pointList.push(point);
    }
    for (var i = 0; i < data.coordinateGroup.length; i++) {
        point = new BMap.Point(data.coordinateGroup[i].flongitude, data.coordinateGroup[i].flatitude);

        map.addOverlay(addEvent(new BMap.Marker(point, {
            icon: myIcon
        }), {
            text: data.coordinateGroup[i].fnickname,
            imgUrl: data.coordinateGroup[i].fheadimgurl,
        }));
        pointList.push(point);

        point2 = new BMap.Point(data.coordinateGroup[i].rlongitude, data.coordinateGroup[i].rlatitude);
        map.addOverlay(addEvent(new BMap.Marker(point2, {
            icon: myIcon2
        }), {
            text: data.coordinateGroup[i].rnickname,
            imgUrl: data.coordinateGroup[i].rheadimgurl,
        }));
        pointList.push(point2);
        polyline = new BMap.Polyline([
            point,
            point2,
        ], {
            strokeColor: lineColor,
            strokeWeight: lineWeight,
            strokeOpacity: lineOpacity
        });
        map.addOverlay(polyline);
    }


    for (var i = 0; i < data.region_coordinateData.length; i++) {
        point = new BMap.Point(data.region_coordinateData[i].CenterLng, data.region_coordinateData[i].CenterLat);
        map.addOverlay(new CircleAniOverlay({
            center: point,
            // length: CircleAniLen,
            text: data.region_coordinateData[i].int + '人'
        }));
        pointList.push(point);
    }
    var viewport = map.getViewport(pointList);
    var center_viewport = viewport.center;
    var zoom_viewport = viewport.zoom;
    // var zoom_viewport = viewport.zoom > 11 ? 11 : viewport.zoom;
    map.centerAndZoom(center_viewport, zoom_viewport);
}

/* 
 * @function 根据地址获取经纬度
 */
function addressToPoint() {
    // 创建地址解析器实例     
    var myGeo = new BMap.Geocoder();
    // 将地址解析结果显示在地图上，并调整地图视野    
    myGeo.getPoint("广东省深圳市龙岗区龙城街道如意路22号", function(point) {
            // if (point) {
            //     map.centerAndZoom(point, 16);
            //     map.addOverlay(new BMap.Marker(point));
            // }
            console.log('point', point);
        },
        "深圳市");
    myGeo.getPoint("广东省深圳市龙岗区龙城街道如意路52号大运路荣超A963设计大厦", function(point) {
        // if (point) {
        //     map.centerAndZoom(point, 16);
        //     map.addOverlay(new BMap.Marker(point));
        // }
        console.log('point2', point);
    });
}
// ----------------------------百度地图 END-------------------------

// ----------------------------数值增长 START-------------------------
function numberGrow() {
    // 数值增长源数据
    var originData = {
        sumDeal_finance: 1291072000,
        fixedCost_finance: 234123010,
    };
    // 数值增长动画数据
    var growData = {};
    for (var key in originData) {
        growData[key] = 0;
    }
    var growTime = 0.6; // 数据增长时间
    var growFps = 60; // 数据fps
    var growCount = growTime * 1000 / growFps; // 数据增长次数
    /* 
     * @function: 数值增长动画
     */
    function growAni() {
        // 归零数值
        zeroGrowHtml();
        var originDataLen = Object.getOwnPropertyNames(originData).length;
        var finishCount = 0;
        for (var key in growData) {
            growData[key] = 0;
        }
        growAniTimeId = setInterval(function() {
            console.log('growAniTimeId');
            finishCount = 0;
            for (var key in growData) {
                growData[key] += Math.ceil(originData[key] / growCount);
                if (growData[key] >= originData[key]) {
                    growData[key] = originData[key];
                    finishCount++;
                }
            }
            // 将增长数值渲染在页面上
            renderGrowData(growData);
            if (finishCount >= originDataLen) {
                clearInterval(growAniTimeId);
            }
        }, growFps);
    }

    function renderGrowData() {
        $sumDeal_finance.html(data.sumDeal_finance);
        $fixedCost_finance.html(data.fixedCost_finance);
    }
}
// ----------------------------数值增长 END-------------------------

// ----------------------------进度条模块 START-------------------------
/* 
<script type="text/html" id="process_template">
    <% for(var i = 0; i < dataArr.length; i++){ %>
        <li class="clearfix" style="opacity:0;animation-delay:<%= i * 0.05 + 0.9 + 's' %>">
            <div class="name">
                <%= dataArr[i].name %>
            </div>
            <div class="process"><span class="fill"><%= dataArr[i].number==0 ? '': dataArr[i].number%>&nbsp;</span></div>
            <div class="number">
                <%= dataArr[i].allNumber %>
            </div>
        </li>
        <% } %>
</script>
ul {
    padding-top: r(3);
    padding-bottom: r(3);
    li {
        // height: r(24);
        // margin-top: r(15);
        height: r(30);
        margin-top: r(10);
        display: flex;
        justify-content: center;
        align-items: center;
        color: #fff;
        font-size: r(24);
        // line-height: 1;
        line-height: r(30);
        .name {
            padding-right: r(10);
            line-height: 1.2;
            overflow: hidden;
            // text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 1;
            white-space: normal;
        }
        .process {
            flex: 1;
            height: r(30);
            border-radius: r(15);
            background-color: #5aabed;
            overflow: hidden;
            .fill {
                display: block;
                width: 0;
                // width: 100px;
                height: 100%;
                // border-radius: r(9);
                background-color: #43defc;
                // background-color: #5dfcfe;
                font-size: r(24);
                line-height: r(30);
                text-align: right;
            }
        }
        .number {
            // min-width: r(55);
            padding-left: r(10);
            text-align: left;
            line-height: 1.2;
            overflow: hidden;
            // text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 1;
            white-space: normal;
        }
    }
}
*/
// 进度条数据
var progressData_houseType = {
    sumHouseAttentive: 0,
    houseAttentive: []
};
var progressAniTime_houseType = 0.5; // 进度条动画时间
/* 
 * @function progressData_houseType
 * @params {data: Object} progressData数据
 */
function renderProgressData_houseType(data) {
    changeProgressData_houseType(data);
    var houseTypeHtml = template('process_houseType_template', { dataArr: data.houseAttentive });
    var $houseTypeHtml = $(houseTypeHtml);
    if (progressData_houseType.sumHouseAttentive == 0) {
        $houseTypeHtml.find('.process').css({
            'background-color': '#5aabed'
        });
    }
    setNameWid_houseType([$houseTypeHtml]);
    $('.houseTypeData>ul').html($houseTypeHtml);
}
/* 
 * @function 设置进度条, 户型名称, 数量宽度
 * @params {$Objs: Array} jQuery对象集合, 0/成交, 1/剩余, 2/关注
 */
function setNameWid_houseType($Objs) {
    var byteLens = [];
    var maxNameWid = 0;
    for (var i = 0; i < progressData_houseType.houseAttentive.length; i++) {
        byteLens.push(getByteLen(progressData_houseType.houseAttentive[i].name));
    }
    maxNameWid = Math.max.apply(null, byteLens) * size(12) + size(30);
    for (var i = 0; i < $Objs.length; i++) {
        $Objs[i].find('.name').css('width', maxNameWid);
    }
}
/* 
 * @function progressData_houseType, fill动画
 * @params {data: Object} progressData_houseType数据
 */
function houseTypeDataAni(data) {
    $('.houseTypeData>ul').find('.fill_visit').each(function(index, ele) {
        $(ele).animate({
            width: data.houseAttentive[index].fill_visit + '%'
        }, progressAniTime_houseType * 1000);
        $(ele).prev('.fill_deal').animate({
            width: data.houseAttentive[index].fill_deal + '%'
        }, progressAniTime_houseType * 1000);
    });
}
// ----------------------------进度条模块 END---------------------------

// ----------------------------柱状图 START-------------------------
/* 
<div class="columnChart">
<div class="chartBg">
    <ul class="clearfix">
        <li>
            <div class="column">
                <span>0</span>
            </div>
            <div class="explain">投资</div>
        </li>
        <li>
            <div class="column"><span>0</span></div>
            <div class="explain">20-30</div>
        </li>
    </ul>
    <div class="cornerMask">单位: 人</div>
</div>
.chartBg {
    width: 100%;
    height: r(300);
    position: relative;
    border-top: 2px solid #b2dcff;
    border-bottom: 2px solid #b2dcff;
    >ul {
        width: 100%;
        height: 100%;
        padding-left: r(9);
        // border-top: 2px solid #b2dcff;
        // border-bottom: 2px solid #b2dcff;
        background-color: #138cf2;
        >li {
            float: left;
            width: r(100);
            height: 100%;
            border-left: 1px solid #42a3f5;
            position: relative;
            &:last-child {
                border-right: 1px solid #42a3f5;
            }
            .column {
                position: absolute;
                bottom: 0;
                left: r(16);
                width: r(68);
                // height: r(200);
                height: 0;
                background-image: linear-gradient(to bottom, #4de6fc 0%, #05b6fc 100%);
                span {
                    position: absolute;
                    top: r(-40);
                    left: 0;
                    width: r(68);
                    text-align: center;
                    font-size: r(30);
                    line-height: 1;
                    color: #fff;
                }
            }
            .explain {
                position: absolute;
                bottom: r(-44);
                left: r(2);
                width: r(96);
                height: r(36);
                background-color: #1e98ea;
                text-align: center;
                font-size: r(28);
                line-height: r(36);
                color: #fff;
                border-radius: r(10);
            }
            &:nth-child(5),
            &:nth-child(6),
            &:nth-child(7) {
                .column {
                    background-image: none;
                    background-color: #fff600;
                }
                .explain {
                    background-color: #31b1f2;
                }
            }
        }
    }
    .cornerMask {
        position: absolute;
        right: r(15);
        top: r(10);
        font-size: r(18);
        color: #fff;
    }
}
*/
function columnChart() {
    var columnChartData = []; // 柱状图数据
    var columnFact = 0.75; // 柱状图因子, 最大数据柱状图到达的高度
    var layoutLiHei = 0; // 最大柱状图数据到达高度
    layoutLiHei = Math.max.apply(null, columnChartData) / columnFact;
    $('.columnChart li>.column').each(function(index, ele) {
        $(ele).animate({
            height: columnChartData[index] / layoutLiHei * columnChartLiHei
        }, clientTypeAniTime);
    });
}
// ----------------------------柱状图 END-------------------------

// ----------------------------echarts折线图模块 START---------------

var lineChart = echarts.init(document.getElementById('lineChartCanvas_echarts'));
var maxCount_day = 10; // 实时数据单位数据
var maxCount_month = 10; // 月数据单位数据
var maxCount_year = 10; // 年数据单位数据
// 实时数据
var lineData_current = {
    visit: [0],
    transmit: [0],
    deal: [0],
    xAxis: [
        '00:00', '', '', '', '04:00', '', '', '', '08:00', '', '', '', '12:00', '', '', '', '16:00', '', '', '', '20:00', '', '', '', '24:00'
    ],
    maxCount: maxCount_day
};
// 月数据
var lineData_month = {
    visit: [],
    transmit: [],
    deal: [],
    xAxis: [],
    maxCount: maxCount_month
};
// 年数据
var lineData_year = {
    visit: [],
    transmit: [],
    deal: [],
    xAxis: [
        '1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'
    ],
    maxCount: maxCount_year
};
// 月标签数据
var lineData_monthData = {
    '28': ['1', '', '3', '', '5', '', '7', '', '9', '', '11', '', '13', '', '15', '', '17', '', '19', '', '21', '', '23', '', '25', '', '', '28'],
    '29': ['1', '', '3', '', '5', '', '7', '', '9', '', '11', '', '13', '', '15', '', '17', '', '19', '', '21', '', '23', '', '25', '', '27', '', '29'],
    '30': ['1', '', '3', '', '5', '', '7', '', '9', '', '11', '', '13', '', '15', '', '17', '', '19', '', '21', '', '23', '', '25', '', '27', '', '', '30'],
    '31': ['1', '', '3', '', '5', '', '7', '', '9', '', '11', '', '13', '', '15', '', '17', '', '19', '', '21', '', '23', '', '25', '', '27', '', '29', '', '31'],
};
var timeId_trendCartAni = null; // 切换折线图定时器id
var trendCartAniCount = 1; // 绘制折线图标识, 0/实时数据, 1/月数据, 2/年数据

/* 
 * @function 处理折线图接口数据
 * @params {data: Object} 接口数据
 */
function changeData_trendChart(data) {
    var days = mGetDate();
    var currentTime = getCurrentTime();
    var hours = currentTime.hours + 1;
    var day = currentTime.day;
    var month = currentTime.month;
    hours = hours <= 1 ? 2 : hours;
    day = day <= 1 ? 2 : day;
    month = month <= 1 ? 2 : month;


    var lineData = data.trendCart;
    lineData_current.visit = lineData.visit_day.slice(0, hours);
    lineData_current.transmit = lineData.forward_day.slice(0, hours);
    lineData_current.deal = lineData.subscription_day.slice(0, hours);

    lineData_month.visit = lineData.visit_month.slice(0, day);
    lineData_month.transmit = lineData.forward_month.slice(0, day);
    lineData_month.deal = lineData.subscription_month.slice(0, day);
    lineData_month.xAxis = lineData_monthData[days];

    lineData_year.visit = lineData.visit_year.slice(0, month);
    lineData_year.transmit = lineData.forward_year.slice(0, month);
    lineData_year.deal = lineData.subscription_year.slice(0, month);

    maxCount_day = Math.ceil(Math.max.apply(null, lineData_current.visit.concat(lineData_current.transmit).concat(lineData_current.deal)) / 10) * 10 || 10;
    maxCount_month = Math.ceil(Math.max.apply(null, lineData_month.visit.concat(lineData_month.transmit).concat(lineData_month.deal)) / 10) * 10 || 10;
    maxCount_year = Math.ceil(Math.max.apply(null, lineData_year.visit.concat(lineData_year.transmit).concat(lineData_year.deal)) / 10) * 10 || 10;

    lineData_current.maxCount = maxCount_day;
    lineData_month.maxCount = maxCount_month;
    lineData_year.maxCount = maxCount_year;

}
/* 
 * @function 初始化折线图
 * @params {data: Object} 接口数据
 */
function initTrendChart_echarts(data) {
    changeData_trendChart(data);
    lineChart.setOption(getOption(lineData_current));
    timeId_trendCartAni = setInterval(function() {
        trendCartAni_echarts();
    }, 30 * 1000);
}
/* 
 * @function 更新折线图
 * @params {data: Object} 接口数据
 */
function resetTrendChart_echarts(data) {
    changeData_trendChart(data);
}
/* 
 * @function 折线图动画
 */
function trendCartAni_echarts() {
    lineChart.clear();
    switch (trendCartAniCount) {
        case 0:
            lineChart.setOption(getOption(lineData_current));
            break;
        case 1:
            lineChart.setOption(getOption(lineData_month));
            break;
        case 2:
            lineChart.setOption(getOption(lineData_year));
            break;
    }
    trendCartAniCount++;
    trendCartAniCount %= 3;
}
/* 
 * @function 获取配置数据
 * @params {option: Object} 选项
 * @params {option.maxCount: Number} y轴最大值
 * @params {option.xAxis: Array} x轴标签数据
 * @params {option.visit: Array} 访问数据
 * @params {option.visit: transmit} 转发数据
 * @params {option.visit: deal} 成交数据
 */
function getOption(option) {
    $('.lineCount').html(option.maxCount)
    var lineOption = {
        color: ['#f070ff', '#249AFA', '#4ace5c'],
        xAxis: {
            type: 'category',
            data: option.xAxis,
            boundaryGap: false,
            axisTick: {
                show: false,
            },
            axisLine: {
                show: true,
                lineStyle: {
                    color: '#ababab',
                    width: 1,
                },
            },
            splitLine: {
                show: true,
                lineStyle: {
                    color: '#e2e2e2',
                },

            },
            axisLabel: {
                margin: 3,
                color: '#ababab',
                fontSize: 16,
                interval: 0
            },
        },
        yAxis: {
            type: 'value',
            splitLine: {
                show: false,
                lineStyle: {
                    color: '#e2e2e2',
                },
            },
            splitArea: {
                show: true,
                areaStyle: {
                    color: "#138cf2"
                }
            },
            show: false,
            axisTick: {
                show: false,
            },
            axisLine: {
                show: true,
                lineStyle: {
                    color: '#b2dcff',
                    width: 0,
                },
            },
            axisLabel: {
                color: '#ababab',
                fontSize: 0
            },
            max: option.maxCount
        },
        grid: {
            left: size(24),
            right: size(24),
            top: 0,
            bottom: 20
        },
        series: [{
                type: 'line',
                data: option.visit,
                showSymbol: false,
                areaStyle: {
                    normal: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: '#f070ff'
                        }, {
                            offset: 1,
                            color: '#fff'
                        }])
                    }
                },
            }, {
                type: 'line',
                data: option.transmit,
                showSymbol: false,
                areaStyle: {
                    normal: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: '#249AFA'
                        }, {
                            offset: 1,
                            color: '#fff'
                        }])
                    }
                },
            },
            {
                type: 'line',
                data: option.deal,
                showSymbol: false,
                areaStyle: {
                    normal: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: '#4ace5c'
                        }, {
                            offset: 1,
                            color: '#fff'
                        }])
                    }
                },
            }
        ]
    };
    return lineOption;
}

// ----------------------------echarts折线图模块模块 END-----------

// ----------------------------折线图 START-------------------------

/* 
<div class="content">
    <div class="header clearfix">
        <div class="num_header"><span class="lineCount">100</span>（单位/人）</div>
        <div class="deal_header"><i></i>成交量</div>
        <div class="transmit_header"><i></i>转发量</div>
        <div class="visit_header"><i></i>访问量</div>
    </div>
    <div class="lineChart">
        <div class="chartBg">
            <ul class="clear
            </ul>
            <canvas id="lineChartCanvas"></canvas>
            <canvas id="lineChartCanvas02"></canvas>
            <canvas id="lineChartCanvas03"></canvas>
        </div>
    </div>
    <div class="btnData clearfix">
        <div class="active current">实时数据</div>
        <div class="month">月数据</div>
        <div class="year">年数据</div>
    </div>
</div>
*/
var timeStart = 19; // 折线图开始绘制位置
var contentWid = 680; // 折线图x轴绘制最大长度
// 数据管理页折线图数据,折线1访问量,实时数据
var trendCartData01 = {
    x: [timeStart],
    y: [],
};
// 数据管理页折线图数据,折线2转发量,实时数据
var trendCartData02 = {
    x: [timeStart],
    y: [],
};
// 数据管理页折线图数据,折线3成交量,实时数据
var trendCartData03 = {
    x: [timeStart],
    y: [],
};
// 数据管理页折线图数据,折线1访问量处理后数据,实时数据
var trendCartData01_change = {
    x: [],
    y: []
};
// 数据管理页折线图数据,折线2转发量处理后数据,实时数据
var trendCartData02_change = {
    x: [],
    y: []
};
// 数据管理页折线图数据,折线3成交量处理后数据,实时数据
var trendCartData03_change = {
    x: [],
    y: []
};
// 数据管理页折线图数据,折线1访问量,月数据
var trendCartData01_month = {
    x: [timeStart],
    y: [],
};
// 数据管理页折线图数据,折线2转发量,月数据
var trendCartData02_month = {
    x: [timeStart],
    y: [],
};
// 数据管理页折线图数据,折线3成交量,月数据
var trendCartData03_month = {
    x: [timeStart],
    y: [],
};
// 数据管理页折线图数据,折线1访问量处理后数据,月数据
var trendCartData01_change_month = {
    x: [],
    y: []
};
// 数据管理页折线图数据,折线2转发量处理后数据,月数据
var trendCartData02_change_month = {
    x: [],
    y: []
};
// 数据管理页折线图数据,折线3成交量处理后数据,月数据
var trendCartData03_change_month = {
    x: [],
    y: []
};
// 数据管理页折线图数据,折线1访问量,年数据
var trendCartData01_year = {
    x: [timeStart],
    y: [],
};
// 数据管理页折线图数据,折线2转发量,年数据
var trendCartData02_year = {
    x: [timeStart],
    y: [],
};
// 数据管理页折线图数据,折线3成交量,年数据
var trendCartData03_year = {
    x: [timeStart],
    y: [],
};
// 数据管理页折线图数据,折线1访问量处理后数据,年数据
var trendCartData01_change_year = {
    x: [],
    y: []
};
// 数据管理页折线图数据,折线2转发量处理后数据,年数据
var trendCartData02_change_year = {
    x: [],
    y: []
};
// 数据管理页折线图数据,折线3成交量处理后数据,年数据
var trendCartData03_change_year = {
    x: [],
    y: []
};
var monthData = {
    'day28': ['1', '', '3', '', '5', '', '7', '', '9', '', '11', '', '13', '', '15', '', '17', '', '19', '', '21', '', '23', '', '25', '', '', '28'],
    'day29': ['1', '', '3', '', '5', '', '7', '', '9', '', '11', '', '13', '', '15', '', '17', '', '19', '', '21', '', '23', '', '25', '', '27', '', '29'],
    'day30': ['1', '', '3', '', '5', '', '7', '', '9', '', '11', '', '13', '', '15', '', '17', '', '19', '', '21', '', '23', '', '25', '', '27', '', '', '30'],
    'day31': ['1', '', '3', '', '5', '', '7', '', '9', '', '11', '', '13', '', '15', '', '17', '', '19', '', '21', '', '23', '', '25', '', '27', '', '29', '', '31'],
};
var timeContentData_current = [
    '00:00', '', '', '', '04:00', '', '', '', '08:00', '', '', '', '12:00', '', '', '', '16:00', '', '', '', '20:00', '', '', '', '24:00'
];
var timeContentData_month = monthData.day30;
var timeContentData_year = [
    '1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'
];
// 折线图 START
var clientWid = document.documentElement.clientWidth; // 浏览器可视区宽度
var ratio = 750 / clientWid; // 设计图750与手机浏览器宽度比例
var screenDpi = 2;
var lineChartCanvas = document.getElementById('lineChartCanvas'); // 折线图canvasDOM
var lineChartCanvas02 = document.getElementById('lineChartCanvas02'); // 折线图canvasDOM
var lineChartCanvas03 = document.getElementById('lineChartCanvas03'); // 折线图canvasDOM
// var lineChartCanvasWid = parseFloat($('.chartBg').css('width'));
// var lineChartCanvasHei = parseFloat($('.chartBg>ul').css('height'));
// var lineChartCanvasWid = parseFloat($(lineChartCanvas).css('width'));
// var lineChartCanvasHei = parseFloat($(lineChartCanvas).css('height'));
var lineChartCanvasWid = 718 / ratio * screenDpi;
var lineChartCanvasHei = (330 / ratio - 4) * screenDpi;
lineChartCanvas.width = lineChartCanvasWid;
lineChartCanvas.height = lineChartCanvasHei;
lineChartCanvas02.width = lineChartCanvasWid;
lineChartCanvas02.height = lineChartCanvasHei;
lineChartCanvas03.width = lineChartCanvasWid;
lineChartCanvas03.height = lineChartCanvasHei;
var c1 = lineChartCanvas.getContext('2d'); // 折线图canvas上下文
var c2 = lineChartCanvas02.getContext('2d'); // 折线图canvas上下文
var c3 = lineChartCanvas03.getContext('2d'); // 折线图canvas上下文

var count01 = 0; // 绘制折线图段计数
var count02 = 0; // 绘制折线图段计数
var count03 = 0; // 绘制折线图段计数
// android, iPhone, 设置不同动画时间, START
// var drawFps = 5; // 折线每段绘制次数
// var drawTime = 30; // 折线每段绘制总时间
// var iPhoneAniTime = 600;
// var androidAniTime = 450;
// var clientTypeAniTime = iPhoneAniTime; // 柱状图动画时间
// var browserObj = browser();
// if (browserObj.android) {
//     drawFps = 1;
//     clientTypeAniTime = androidAniTime;
// } else if (browserObj.iPhone) {
//     drawFps = 1;
//     clientTypeAniTime = iPhoneAniTime;
// }
// var drawIntervalTime = drawTime / drawFps;
// android, iPhone, 设置不同动画时间, END
var drawTime_all = 30; // 折线图每段绘制时间, 设置此变量方便只改这一处
var lineCount = 2.5; // 计算每段绘制时间因子, 实时数据, 月数据, 年数据每段绘制时间都不同
var drawIntervalTime = drawTime_all; // 折线图每段绘制时间
var viewColor = '#51feff'; // 访问量折线颜色
var transmitColor = '#fffb82'; // 转发量折线颜色
var dealColor = '#ffbd82'; // 成交量折线颜色
// 折线图
var trendCartFlag = false; // 绘制折线标识, false可开始绘制, true有折线正在绘制, 不可再开始绘制
var timeId = null; // 绘制折线定时器ID
var timeId02 = null; // 绘制折线定时器ID
var timeId03 = null; // 绘制折线定时器ID
var lineCount_day = 100; // 折线图 实时数据单位/人, 根据数据改变
var lineCount_month = 100; // 折线图 月数据单位/人, 根据数据改变
var lineCount_year = 100; // 折线图 年数据单位/人, 根据数据改变
// 折线图, 点击实时数据
var trendCartBtnFlag = 'current'; // 标识当前高亮按钮, 绘制该按钮对应逻辑数据
$('.trendCart .current').on('tap', function() {
    if (trendCartBtnFlag == 'current' || trendCartFlag) {
        return;
    }
    trendCartBtnFlag = 'current';
    $(this).addClass('active').siblings().removeClass('active');
    lineCount = 2.5;
    $('.lineCount').html(lineCount_day);
    changeTimeContent(timeContentData_current);
    drawLineChart(trendCartData01_change, viewColor, trendCartData02_change, transmitColor, trendCartData03_change, dealColor);
});
// 折线图, 点击月数据
$('.trendCart .month').on('tap', function() {
    if (trendCartBtnFlag == 'month' || trendCartFlag) {
        return;
    }
    trendCartBtnFlag = 'month';
    $(this).addClass('active').siblings().removeClass('active');
    lineCount = 3;
    $('.lineCount').html(lineCount_month);
    changeTimeContent(timeContentData_month);
    drawLineChart(trendCartData01_change_month, viewColor, trendCartData02_change_month, transmitColor, trendCartData03_change_month, dealColor);
});
// 折线图, 点击年数据
$('.trendCart .year').on('tap', function() {
    if (trendCartBtnFlag == 'year' || trendCartFlag) {
        return;
    }
    trendCartBtnFlag = 'year';
    $(this).addClass('active').siblings().removeClass('active');
    lineCount = 1;
    $('.lineCount').html(lineCount_year);
    changeTimeContent(timeContentData_year);
    drawLineChart(trendCartData01_change_year, viewColor, trendCartData02_change_year, transmitColor, trendCartData03_change_year, dealColor);
});
/* 
 * @function 修改timeContentData_month数据
 */
function changeTime_month() {
    var days = mGetDate();
    switch (days) {
        case 28:
            timeContentData_month = monthData.day28;
            break;
        case 29:
            timeContentData_month = monthData.day29;
            break;
        case 30:
            timeContentData_month = monthData.day30;
            break;
        case 31:
            timeContentData_month = monthData.day31;
            break;
    }
}
/* 
 * @function 绘制折线
 */
function drawLineChart(data, color, data02, color02, data03, color03) {
    console.log('drawLineChart');
    drawIntervalTime = drawTime_all;
    drawIntervalTime = drawIntervalTime / lineCount;
    count01 = 0;
    count02 = 0;
    count03 = 0;
    c1.clearRect(0, 0, lineChartCanvas.width, lineChartCanvas.height);
    c2.clearRect(0, 0, lineChartCanvas02.width, lineChartCanvas02.height);
    c3.clearRect(0, 0, lineChartCanvas03.width, lineChartCanvas03.height);
    drawLineAni01(data, color);
    drawLineAni02(data02, color02);
    drawLineAni03(data03, color03);
}
/* 
 * @function 绘制折线, 没有动画
 */
function drawLineAni01(data, color) {
    var x0 = data.x[count01];
    var y0 = data.y[count01];
    var x1 = data.x[count01 + 1];
    var y1 = data.y[count01 + 1];
    c1.lineWidth = 3;
    c1.lineCap = 'round';
    c1.lineJoin = 'round';
    c1.strokeStyle = color;
    // console.log('timeId');
    c1.beginPath();
    c1.moveTo(x0, y0);
    c1.lineTo(x1, y1);
    c1.stroke();
    count01++;
    if (count01 == data.y.length - 1) {
        return;
    }
    drawLineAni01(data, color);
}
/* 
 * @function 绘制折线, 每段为一次动画, 动画不细腻
 */
function drawLineAni02(data, color) {
    clearInterval(timeId);
    if (data.y.length <= 1) {
        c1.beginPath();
        // c1.moveTo(0, lineChartCanvasHei);
        // c1.lineTo(data.x[count01], data.y[count01]);
        // c1.stroke();
        c1.fillStyle = color;
        c1.arc(data.x[count01], data.y[count01], 10, 0, 2 * Math.PI);
        c1.fill();
        return;
    }
    trendCartFlag = true;
    var len = data.y.length
    var x0 = data.x[count01];
    var y0 = data.y[count01];
    var x1 = data.x[count01 + 1];
    var y1 = data.y[count01 + 1];
    c1.lineWidth = 2 * screenDpi;
    c1.lineCap = 'round';
    c1.lineJoin = 'round';
    c1.strokeStyle = color;
    timeId = setInterval(function() {
        console.log('timeId');
        c1.beginPath();
        c1.moveTo(x0, y0);
        c1.lineTo(x1, y1);
        c1.stroke();
        count01++;
        if (count01 == len - 1) {
            trendCartFlag = false;
            clearInterval(timeId);
            return;
        }
        drawLineAni02(data, color);
    }, drawIntervalTime);
}
/* 
 * @function 绘制折线, 每段几次动画, 根据浏览器, 操作系统, 可能有断层问题
 */
function drawLineAni03(data, color) {
    timeIdCount = 0;
    clearInterval(timeId);
    trendCartFlag = true;
    var x0 = data.x[count01];
    var y0 = data.y[count01];
    var x1 = data.x[count01 + 1];
    var y1 = data.y[count01 + 1];
    var growNum_x = (x1 - x0) / drawFps;
    var growNum_y = (y1 - y0) / drawFps;
    var current_x = x0;
    var current_y = y0;
    c1.lineWidth = 2 * screenDpi;
    c1.lineCap = 'round';
    c1.lineJoin = 'round';
    c1.strokeStyle = color;
    timeId = setInterval(function() {
        timeIdCount++;
        console.log('timeIdCount', timeIdCount);
        console.log('timeId');
        c1.beginPath();
        c1.moveTo(current_x, current_y);
        current_x += growNum_x;
        current_y += growNum_y;
        c1.lineTo(current_x, current_y);
        c1.stroke();
        if (current_x >= x1) {
            current_x = x1;
            current_y = y1;
            count01++;
            if (count01 == data.y.length - 1) {
                trendCartFlag = false;
                clearInterval(timeId);
                return;
            }
            drawLineAni03(data, color);
        }
        // c1.lineTo(current_x, current_y);
        // c1.stroke();
    }, drawIntervalTime);
}
// ----------------------------折线图 END-------------------------

// ----------------------------类表格布局模块 START-------------------------
/* 
<div class="packAndshowBox first_table">
    <div class="name_packAndshow name_first_table">包装/展示</div>
    <div class="content_packAndshow content_first_table">
        <!-- <div>
            <div class="subName_packAndshow name_second_table">材料</div>
            <div class="subContent_packAndshow content_second_table">
                <div class="newAdd">
                    <div>1</div>
                    <div>2</div>
                    <div>3</div>
                    <div>4</div>
                    <div class="editBox">
                        <div class="fileBtn">附 件</div>
                        <div class="removeBtn">删 除</div>
                    </div>
                </div>
                <div class="AddSubContent">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div>
                    </div>
                </div>
            </div>
        </div> -->
        <div class="addCategory_packAndshow addCategory">
            <div class="subName_packAndshow name_second_table selectBox">
                <div class="infoBox clearfix changeBox">
                    <div class="inputBox">
                        <div class="select mainBg" onselectstart="return false">添加类目</div>
                        <div class="triangle"></div>
                        <div class="optionBox" data-kpl="包装/展示" data-kplen="packing">
                            <ul>
                                <li data-name="工地围墙">工地围墙</li>
                                <li data-name="主入口">主入口</li>
                                <li data-name="灯杆旗">灯杆旗</li>
                                <li data-name="看楼通道/楼体">看楼通道/楼体</li>
                        </div>
                    </div>
                </div>
            </div>
            <div class="subContent_packAndshow content_second_table">
                <div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>
        </div>
    </div>
</div>

>div {
    &.name_first_table {
        width: 150px;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    &.content_first_table {
        flex: 1;
        border-right-width: 0;
        text-align: center;
        >div {
            width: 100%;
            display: flex;
            border-bottom: 1px solid #e6e6e6;
            &:last-child {
                border-bottom-width: 0;
            }
        }
        .name_second_table {
            width: 200px;
            border-right: 1px solid #e6e6e6;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .content_second_table {
            // width: 199px;
            flex: 1;
            // border-right: 1px solid #e6e6e6;
            >div {
                width: 100%;
                height: 50px;
                border-bottom: 1px solid #e6e6e6;
                display: flex;
                &:last-child {
                    border-bottom-width: 0;
                }
                >div {
                    border-right: 1px solid #e6e6e6;
                    input {
                        box-sizing: border-box;
                        width: 100%;
                        height: 90%;
                        padding: 0 10px;
                        border-width: 0;
                        color: #777;
                        font-size: 16px;
                        text-align: center;
                    }
                    &:nth-child(1) {
                        width: 200px;
                    }
                    &:nth-child(2) {
                        flex: 1;
                    }
                    &:nth-child(3) {
                        flex: 1;
                    }
                    &:nth-child(4) {
                        flex: 1;
                    }
                    &:nth-child(5) {
                        width: 100px;
                        border-right-width: 0;
                    }
                }
            }
        }
        .selectBox {
            display: flex;
            justify-content: space-around;
            align-items: center;
            height: 48px;
            >div {
                // float: left;
            }
            .input_houseNum {
                width: 170px;
                height: 32px;
                border: 1px solid #209aff;
                padding: 0 5px;
                display: flex;
                align-items: center;
                input {
                    width: 110px;
                    border-width: 0;
                    text-align: center;
                    color: #209aff;
                    font-size: 16px;
                }
            }
        }
        .newAdd {
            >div {
                input {
                    box-sizing: border-box;
                    width: 100%;
                    height: 90%;
                    padding: 0 10px;
                    border-width: 0;
                    color: #777;
                    font-size: 16px;
                    text-align: center;
                }
                &:first-child {}
                &.remarkBox {
                    input {
                        box-sizing: border-box;
                        width: 100%;
                        height: 100%;
                        font-size: 16px;
                        color: #777;
                        border-width: 0;
                        padding: 0 20px;
                        text-align: center;
                    }
                }
            }
        }
        .AddSubContent {
            >div {
                &:first-child {
                    background-image: url('/public/static/admin/images/public/add_market.png');
                    background-repeat: no-repeat;
                    background-position: center center;
                    cursor: pointer;
                }
            }
        }
    }
}
*/
// ----------------------------类表格布局模块 END---------------------------