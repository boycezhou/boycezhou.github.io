    // 地图参数配置
    var mapConfig = {
        iconScale: 0.8,
        lineColor: '#ff5722',
        lineWeight: 2,
        lineOpacity: 1,
        arrowHeight: 10,
        imgShowSize: 40,
        imgUrl_default: '/public/static/admin/images/public/02_mapPortrait.png',
        circleColor: 'rgba(108,186,250,0.8)',
        circleRadius: 70,
        fontSize_circle: 12,
    };
    // 自定义覆盖物类, 透明圆形
    function CircleAniOverlay(option) {
        this._center = option.center;
        this._length = option.length;
        this._color = option.color || mapConfig.circleColor;
        this._text = option.text;
    }

    // 继承API的BMap.Overlay
    CircleAniOverlay.prototype = new BMap.Overlay();
    // 实现初始化方法  
    CircleAniOverlay.prototype.initialize = function(map) {
            // 保存map对象实例
            this._map = map;
            this._length = this._length || mapConfig.circleRadius;
            var fontSize = mapConfig.fontSize_circle;
            // 创建div元素，作为自定义覆盖物的容器
            var html = '<div></div>';
            var $html = $(html);
            $html.css({
                'background-color': this._color,
                'position': 'absolute',
                'width': this._length,
                'height': this._length,
                'line-height': this._length + 'px',
                'font-size': fontSize,
            });
            $html.html(this._text);
            $html.addClass('circleAniOverlay');
            var div = $html.get(0);
            var circleMaskDOM = $('<div class="circleMask"></div>')[0];
            var circle01DOM = $('<div class="circle circle01"></div>')[0];
            var circle02DOM = $('<div class="circle circle02"></div>')[0];
            var circle03DOM = $('<div class="circle circle03"></div>')[0];
            div.appendChild(circleMaskDOM);
            div.appendChild(circle01DOM);
            div.appendChild(circle02DOM);
            div.appendChild(circle03DOM);
            // 将div添加到覆盖物容器中
            map.getPanes().markerPane.appendChild(div);
            // 保存div实例
            this._div = div;
            // 需要将div元素作为方法的返回值，当调用该覆盖物的show、
            // hide方法，或者对覆盖物进行移除时，API都将操作此元素。
            return div;
        }
        // 实现绘制方法   
    CircleAniOverlay.prototype.draw = function() {
        // 根据地理坐标转换为像素坐标，并设置给容器    
        var position = this._map.pointToOverlayPixel(this._center);
        this._div.style.left = position.x - this._length / 2 + "px";
        this._div.style.top = position.y - this._length / 2 + "px";
    };

    // 自定义覆盖物类, 透明圆形
    function ImgCircleOverlay(option) {
        this._center = option.center;
        this._length = option.length;
        this._text = option.text;
        this._angle = option.angle;
        this._imgUrl = option.imgUrl;
        this._className = option.className || '';
    }
    // 继承API的BMap.Overlay
    ImgCircleOverlay.prototype = new BMap.Overlay();
    // 实现初始化方法  
    ImgCircleOverlay.prototype.initialize = function(map) {
            // 保存map对象实例
            this._map = map;
            this._length = this._length || 40;
            this._imgUrl = this._imgUrl || mapConfig.imgUrl_default;
            // 创建div元素，作为自定义覆盖物的容器
            var html = '<div></div>';
            var $html = $(html);
            $html.addClass(this._className);
            $html.css({
                'position': 'absolute',
                'width': this._length + 'px',
                'height': this._length + 'px',
                'border-radius': '50%',
                'box-sizing': 'border-box',
                overflow: 'hidden',
                curser: 'pointer',
                'box-shadow': '0 0 30px 0 rgba(0, 0, 0, 0.1)',
                border: '2px solid rgba(108, 186, 250, 0.8)'
            });
            var $img = $('<img src="' + this._imgUrl + '" />');
            $img.css({
                width: '100%',
                height: '100%'
            });
            $html.html($img);
            var div = $html.get(0);
            // 将div添加到覆盖物容器中
            map.getPanes().markerPane.appendChild(div);
            // 保存div实例
            this._div = div;
            // 需要将div元素作为方法的返回值，当调用该覆盖物的show、
            // hide方法，或者对覆盖物进行移除时，API都将操作此元素。
            return div;
        }
        // 实现绘制方法   
    ImgCircleOverlay.prototype.draw = function() {
        // 根据地理坐标转换为像素坐标，并设置给容器    
        var offsetObj = {};
        var position = this._map.pointToOverlayPixel(this._center);
        if (this._angle || this._angle == 0) {
            offsetObj = offsetImg(this._angle);
            this._div.style.left = position.x - offsetObj.left + "px";
            this._div.style.top = position.y - offsetObj.top + "px";
        } else {
            this._div.style.left = position.x - this._length / 2 + "px";
            this._div.style.top = position.y - this._length / 2 + "px";
        }
    };

    // 自定义覆盖物类, 透明圆形
    function DealCircleOverlay(option) {
        this._center = option.center;
        this._length = option.length;
        this._color = option.color;
        // this._color = '#f85a40';
    }

    // 继承API的BMap.Overlay
    DealCircleOverlay.prototype = new BMap.Overlay();
    // 实现初始化方法  
    DealCircleOverlay.prototype.initialize = function(map) {
            // 保存map对象实例
            this._map = map;
            this._length = this._length || 8;
            var fontSize = '18px';
            // 创建div元素，作为自定义覆盖物的容器
            var html = '<div></div>';
            var $html = $(html);
            $html.css({
                'background-color': this._color,
                'position': 'absolute',
                'width': this._length,
                'height': this._length,
                'border-radius': '50%'
            });
            // $html.addClass('dealCircleOverlay');
            var div = $html.get(0);

            // 将div添加到覆盖物容器中
            map.getPanes().markerPane.appendChild(div);
            // 保存div实例
            this._div = div;
            // 需要将div元素作为方法的返回值，当调用该覆盖物的show、
            // hide方法，或者对覆盖物进行移除时，API都将操作此元素。
            return div;
        }
        // 实现绘制方法   
    DealCircleOverlay.prototype.draw = function() {
        // 根据地理坐标转换为像素坐标，并设置给容器    
        var position = this._map.pointToOverlayPixel(this._center);
        this._div.style.left = position.x - this._length / 2 + "px";
        this._div.style.top = position.y - this._length / 2 + "px";
    };

    var myIcon = new BMap.Icon("/public/static/admin/images/public/icon_map_exit.png", new BMap.Size(58, 69), {
        anchor: new BMap.Size(30 * mapConfig.iconScale, 57 * mapConfig.iconScale),
        imageSize: new BMap.Size(58 * mapConfig.iconScale, 69 * mapConfig.iconScale),
    });
    var myIcon2 = new BMap.Icon("/public/static/admin/images/public/icon_map_enter.png", new BMap.Size(58, 69), {
        anchor: new BMap.Size(30 * mapConfig.iconScale, 57 * mapConfig.iconScale),
        imageSize: new BMap.Size(58 * mapConfig.iconScale, 69 * mapConfig.iconScale),
    });
    var myIcon3 = new BMap.Icon("/public/static/admin/images/public/icon_map.png", new BMap.Size(58, 69), {
        anchor: new BMap.Size(30 * mapConfig.iconScale, 57 * mapConfig.iconScale),
        imageSize: new BMap.Size(58 * mapConfig.iconScale, 69 * mapConfig.iconScale),
    });
    var myIcon4 = new BMap.Icon("/public/static/admin/images/public/dealicon_map.png", new BMap.Size(58, 69), {
        anchor: new BMap.Size(30 * mapConfig.iconScale, 57 * mapConfig.iconScale),
        imageSize: new BMap.Size(58 * mapConfig.iconScale, 69 * mapConfig.iconScale),
    });
    var myIcon5 = new BMap.Icon("/public/static/admin/images/public/visitlicon_map.png", new BMap.Size(58, 69), {
        anchor: new BMap.Size(30 * mapConfig.iconScale, 57 * mapConfig.iconScale),
        imageSize: new BMap.Size(58 * mapConfig.iconScale, 69 * mapConfig.iconScale),
    });
    var arrow_map = new BMap.Icon("/public/static/admin/images/public/arrow_map.png", new BMap.Size(10, 10), {
        anchor: new BMap.Size(5, 5),
    });
    /* 
     * @function 给marker添加移入移除事件
     * @params {marker: BMap.Marker}
     * @params {option: Object} 选项
     * @params {option.text: String} 显示文本
     * @params {option.imgUrl: String} 头像
     * @params {option.hideImg: Boolean} true / 不显示头像, false / 显示头像(默认)
     */
    function addEvent(marker, option) {
        option.imgUrl = option.imgUrl == '' ? mapConfig.imgUrl_default : option.imgUrl;
        var leftX = 40;
        var topY = -45;
        var labelContent = '';
        if (!option.text) {
            labelContent = '<div><p style="color:#fff;">' + option.address + '</p></div>';
            topY = -25;
        } else if (option.hideImg) {
            labelContent = '<div><p style="color:#fff">' + option.text + '：</p><p style="color:#fff">' + option.address + '</p></div>'
        } else {
            labelContent = '<div><p style="color:#fff;width:30px;height:30px;padding-left:35px;line-height:30px;position:relative;"><img style="position:absolute;left:0;top:0;width:30px;height:30px;border-radius:50%" src="' + option.imgUrl + '" >' + option.text + '：</p><p style="color:#fff">' + option.address + '</p></div>';
            topY = -55;
        }
        marker.addEventListener("mouseover", function(e) {
            var label = new BMap.Label(labelContent, {
                offset: new BMap.Size(leftX, topY)
            }); //为标注设置一个标签
            label.setStyle({
                // width: "120px",
                color: '#fff',
                background: '#ff8355',
                border: 'none',
                borderRadius: "5px",
                height: "auto",
                'line-height': 1.5,
                padding: '2px 5px',
                'font-size': '14px'
            });
            marker.setLabel(label);
        });
        marker.addEventListener("mouseout", function(e) {
            var label = this.getLabel();
            label.setContent(""); //设置标签内容为空
            label.setStyle({
                border: "none",
                width: "0px",
                padding: "0px"
            }); //设置标签边框宽度为0
        });
        return marker;
    }
    /* 
     * @function 地图, 箭头覆盖物
     */
    function arrowMarker(option) {
        var arrowIcon = option.arrowIcon || arrow_map;
        var startPoint = option.startPoint;
        var endPoint = option.endPoint;
        var marker_arrow = new BMap.Marker(endPoint, {
            icon: arrowIcon
        });
        marker_arrow.setRotation(option.angle);
        return marker_arrow;
    }
    /* 
     * @function 计算两点间的角度
     */
    function calcAngle(start, end, map) {
        var p_start = map.pointToPixel(start),
            p_end = map.pointToPixel(end);
        var diff_x = p_end.x - p_start.x,
            diff_y = p_end.y - p_start.y;
        return 360 * Math.atan2(diff_y, diff_x) / (2 * Math.PI) + 90;
    }
    /* 
     * @function 计算头像需要偏移量
     */
    function offsetImg(angle) {
        var iconR = mapConfig.imgShowSize / 2;
        var imgR = mapConfig.arrowHeight / 2;
        return {
            left: iconR - (iconR + imgR - 2) * Math.sin(Math.PI * angle / 180),
            top: iconR + (iconR + imgR - 2) * Math.cos(Math.PI * angle / 180)
        };
    }
    /* 
     * @function 移入移除显示label
     * @parmas {option: Object} 选项
     * @parmas {option.map: BMap.Map} 
     * @parmas {option.point: BMap.Point} 
     * @parmas {option.divClass: String} 类名
     * @parmas {option.mapId: String} map容器的id名
     * @parmas {option.angle: Number} 旋转角度
     * @parmas {option.text: String} 昵称
     * @parmas {option.address: String} 地址
     */
    function toggleLabel(option) {
        var divClass = option.divClass;
        var mapId = option.mapId || 'container_map';
        var map = option.map;
        var point = option.point;
        var angle = option.angle || 0;
        var text = option.text || '';
        var address = option.address || '';
        var imgSize = mapConfig.imgShowSize;
        var offsetObj = offsetImg(angle);
        var leftX = imgSize - offsetObj.left + 2;
        var topY = angle == 0 ? -offsetObj.top : -offsetObj.top - imgSize / 2;
        topY = topY - 10;
        var divDom = '<div><p style="color:#fff">' + text + '：</p><p style="color:#fff">' + address + '</p></div>';
        var label = new BMap.Label(text, {
            position: point,
            offset: new BMap.Size(leftX, topY),
        }); //为标注设置一个标签
        $('#' + mapId).on("mouseover", '.' + divClass, function(e) {
            label.setContent(divDom);
            label.setStyle({
                width: "auto",
                color: '#fff',
                background: '#ff8355',
                border: 'none',
                borderRadius: "5px",
                height: "auto",
                'line-height': '1.5',
                padding: '2px 5px',
                'font-size': '14px',
                curser: 'pointer'
            });
            map.addOverlay(label);
        });
        $('#container_map').on("mouseout", '.' + divClass, function(e) {
            label.setContent(""); //设置标签内容为空
            label.setStyle({
                border: "none",
                width: "0px",
                padding: "0px"
            }); //设置标签边框宽度为0
        });
    }

    /* 
     * @function 地图
     */
    function map() {
        var longitude = 114.055353;
        var latitude = 22.562075;
        var myIconSize = '16px';
        var json = mapJson;
        var map = new BMap.Map("container_map");
        // 创建地图实例  
        var point = new BMap.Point(longitude, latitude);
        // 创建点坐标  
        map.centerAndZoom(point, 19);

        map.setMapStyle({
            styleJson: json
        });
        //禁止拖拽
        // map.disableDragging();
        // 开启鼠标缩放
        map.enableScrollWheelZoom(true);
        return map;
    }
    /* 
     * @function 给marker添加移入移除事件
     * @params {marker: BMap.Marker}
     * @params {option: Object} 选项
     * @params {option.text: String} 显示文本
     * @params {option.imgUrl: String} 头像
     * @params {option.hideImg: Boolean} true / 不显示头像, false / 显示头像(默认)
     */
    function addEvent(marker, option) {
        option.imgUrl = option.imgUrl == '' ? mapConfig.imgUrl_default : option.imgUrl;
        var leftX = 40;
        var topY = -45;
        var labelContent = '';
        if (!option.text) {
            labelContent = '<div><p style="color:#fff;">' + option.address + '</p></div>';
            topY = -25;
        } else if (option.hideImg) {
            labelContent = '<div><p style="color:#fff">' + option.text + '：</p><p style="color:#fff">' + option.address + '</p></div>'
        } else {
            labelContent = '<div><p style="color:#fff;width:30px;height:30px;padding-left:35px;line-height:30px;position:relative;"><img style="position:absolute;left:0;top:0;width:30px;height:30px;border-radius:50%" src="' + option.imgUrl + '" >' + option.text + '：</p><p style="color:#fff">' + option.address + '</p></div>';
            topY = -55;
        }
        marker.addEventListener("mouseover", function(e) {
            var label = new BMap.Label(labelContent, {
                offset: new BMap.Size(leftX, topY)
            }); //为标注设置一个标签
            label.setStyle({
                // width: "120px",
                color: '#fff',
                background: '#ff8355',
                border: 'none',
                borderRadius: "5px",
                height: "auto",
                'line-height': 1.5,
                padding: '2px 5px',
                'font-size': '14px'
            });
            marker.setLabel(label);
        });
        marker.addEventListener("mouseout", function(e) {
            var label = this.getLabel();
            label.setContent(""); //设置标签内容为空
            label.setStyle({
                border: "none",
                width: "0px",
                padding: "0px"
            }); //设置标签边框宽度为0
        });
        return marker;
    }
    /* 
     * @function 地图, 箭头覆盖物
     */
    function arrowMarker(option) {
        var arrowIcon = option.arrowIcon || arrow_map;
        var startPoint = option.startPoint;
        var endPoint = option.endPoint;
        var marker_arrow = new BMap.Marker(endPoint, {
            icon: arrowIcon
        });
        marker_arrow.setRotation(option.angle);
        return marker_arrow;
    }
    /* 
     * @function 计算两点间的角度
     */
    function calcAngle(start, end, map) {
        var p_start = map.pointToPixel(start),
            p_end = map.pointToPixel(end);
        var diff_x = p_end.x - p_start.x,
            diff_y = p_end.y - p_start.y;
        return 360 * Math.atan2(diff_y, diff_x) / (2 * Math.PI) + 90;
    }
    /* 
     * @function 计算头像需要偏移量
     */
    function offsetImg(angle) {
        var iconR = mapConfig.imgShowSize / 2;
        var imgR = mapConfig.arrowHeight / 2;
        return {
            left: iconR - (iconR + imgR - 2) * Math.sin(Math.PI * angle / 180),
            top: iconR + (iconR + imgR - 2) * Math.cos(Math.PI * angle / 180)
        };
    }

    function addArrow(polyline, length, angleValue) { //绘制箭头的函数  
        var linePoint = polyline.getPath(); //线的坐标串  
        var arrowCount = linePoint.length;
        for (var i = 1; i < arrowCount; i++) { //在拐点处绘制箭头  
            var pixelStart = map.pointToPixel(linePoint[i - 1]);
            var pixelEnd = map.pointToPixel(linePoint[i]);
            var angle = angleValue; //箭头和主线的夹角  
            var r = length; // r/Math.sin(angle)代表箭头长度  
            var delta = 0; //主线斜率，垂直时无斜率  
            var param = 0; //代码简洁考虑  
            var pixelTemX, pixelTemY; //临时点坐标  
            var pixelX, pixelY, pixelX1, pixelY1; //箭头两个点  
            if (pixelEnd.x - pixelStart.x == 0) { //斜率不存在是时  
                pixelTemX = pixelEnd.x;
                if (pixelEnd.y > pixelStart.y) {
                    pixelTemY = pixelEnd.y - r;
                } else {
                    pixelTemY = pixelEnd.y + r;
                }
                //已知直角三角形两个点坐标及其中一个角，求另外一个点坐标算法  
                pixelX = pixelTemX - r * Math.tan(angle);
                pixelX1 = pixelTemX + r * Math.tan(angle);
                pixelY = pixelY1 = pixelTemY;
            } else //斜率存在时  
            {
                delta = (pixelEnd.y - pixelStart.y) / (pixelEnd.x - pixelStart.x);
                param = Math.sqrt(delta * delta + 1);

                if ((pixelEnd.x - pixelStart.x) < 0) //第二、三象限  
                {
                    pixelTemX = pixelEnd.x + r / param;
                    pixelTemY = pixelEnd.y + delta * r / param;
                } else //第一、四象限  
                {
                    pixelTemX = pixelEnd.x - r / param;
                    pixelTemY = pixelEnd.y - delta * r / param;
                }
                //已知直角三角形两个点坐标及其中一个角，求另外一个点坐标算法  
                pixelX = pixelTemX + Math.tan(angle) * r * delta / param;
                pixelY = pixelTemY - Math.tan(angle) * r / param;

                pixelX1 = pixelTemX - Math.tan(angle) * r * delta / param;
                pixelY1 = pixelTemY + Math.tan(angle) * r / param;
            }

            var pointArrow = map.pixelToPoint(new BMap.Pixel(pixelX, pixelY));
            var pointArrow1 = map.pixelToPoint(new BMap.Pixel(pixelX1, pixelY1));
            var Arrow = new BMap.Polyline([
                pointArrow,
                linePoint[i],
                pointArrow1
            ], {
                strokeColor: lineColor,
                strokeWeight: lineWeight,
                strokeOpacity: lineOpacity
            });
            map.addOverlay(Arrow);
        }
    }

    /* 
     * @function 绘制地图覆盖物
     * @params {map: Bmap.Map} 地图对象
     * @params {data: Object} 接口数据
     * @params {mapConfig: Object} 地图参数配置(自定义)
     */
    function drawMap(map, data, mapConfig) {
        var pointList = [];
        var CircleAniLen = 48;
        var CircleColor = 'rgba(197,125,160,0.8)';
        var lineColor = mapConfig.lineColor;
        var lineWeight = mapConfig.lineWeight;
        var lineOpacity = mapConfig.lineOpacity;
        var point = null;
        var point2 = null;
        var polyline = null;
        var angle = null;
        var className1 = '';
        for (var i = 0; i < data.customervisitData.length; i++) {
            point = new BMap.Point(data.customervisitData[i].longitude, data.customervisitData[i].latitude);
            // map.addOverlay(addEvent(new BMap.Marker(point, {
            //     icon: myIcon3
            // }), {
            //     text: data.customervisitData[i].nickname,
            //     imgUrl: data.customervisitData[i].headimgurl,
            // }));
            className1 = 'div' + getRandom();
            map.addOverlay(new ImgCircleOverlay({
                center: point,
                imgUrl: data.customervisitData[i].headimgurl,
                className: className1
            }));
            toggleLabel({
                divClass: className1,
                map: map,
                point: point,
                text: data.customervisitData[i].nickname,
                address: data.customervisitData[i].address,
            });
        }

        for (var i = 0; i < data.coordinateGroup.length; i++) {
            point = new BMap.Point(data.coordinateGroup[i].flongitude, data.coordinateGroup[i].flatitude);
            point2 = new BMap.Point(data.coordinateGroup[i].rlongitude, data.coordinateGroup[i].rlatitude);
            angle = calcAngle(point, point2, map);
            polyline = new BMap.Polyline([
                point,
                point2,
            ], {
                strokeColor: lineColor,
                strokeWeight: lineWeight,
                strokeOpacity: lineOpacity
            });
            // map.addOverlay(addEvent(new BMap.Marker(point, {
            //     icon: myIcon
            // }), {
            //     text: data.coordinateGroup[i].fnickname,
            //     imgUrl: data.coordinateGroup[i].fheadimgurl,
            // }));
            // map.addOverlay(addEvent(new BMap.Marker(point2, {
            //     icon: myIcon2
            // }), {
            //     text: data.coordinateGroup[i].rnickname,
            //     imgUrl: data.coordinateGroup[i].rheadimgurl,
            // }));
            map.addOverlay(polyline);
            map.addOverlay(arrowMarker({
                startPoint: point,
                endPoint: point2,
                angle: angle
            }));
            map.addOverlay(new ImgCircleOverlay({
                center: point,
                imgUrl: data.coordinateGroup[i].fheadimgurl,
            }));
            map.addOverlay(new ImgCircleOverlay({
                center: point2,
                angle: angle,
                imgUrl: data.coordinateGroup[i].rheadimgurl,
            }));

            pointList.push(point);
            pointList.push(point2);
        }

        for (var i = 0; i < data.region_coordinateData.length; i++) {
            point = new BMap.Point(data.region_coordinateData[i].CenterLng, data.region_coordinateData[i].CenterLat);
            map.addOverlay(new CircleAniOverlay({
                center: point,
                // length: CircleAniLen,
                text: data.region_coordinateData[i].int + '人'
            }));
            pointList.push(point);
        }
        var viewport = map.getViewport(pointList);
        var center_viewport = viewport.center;
        var zoom_viewport = viewport.zoom;
        map.centerAndZoom(center_viewport, zoom_viewport);

    }
    /*
        // 地图样式
     .anchorBL {
        display: none;
    }

    .BMap_scaleCtrl {
        display: block !important;
        left: 0 !important;
        bottom: 0 !important;
    }

    .circle {
        animation: circle 4.5s linear infinite;
    }

    @keyframes circle {
        from {
            opacity: 1;
            -webkit-transform: scale(1);
        }
        to {
            opacity: 0;
            -webkit-transform: scale(1.8);
        }
    }

    .circleAniOverlay {
        position: absolute;
        // width: 48px;
        // height: 48px;
        // line-height: 48px;
        // font-size: 12px;
        text-align: center;
        border-radius: 50%;
        color: #fff;
        // border: 1px solid rgba(255, 255, 255, 1);
        box-sizing: border-box;
        >.circle,
        .circleMask {
            border-radius: 50%;
            position: absolute;
            top: 0px;
            left: 0px;
            width: 100%;
            height: 100%;
            box-sizing: border-box;
            // border: 1px solid #6cbafa;
            border: 1px solid rgba(184, 221, 252, 1);
            // border: 1px solid rgba(255, 255, 255, 1);
            &.circle01 {
                animation-delay: 0s;
            }
            &.circle02 {
                animation-delay: 1.5s;
            }
            &.circle03 {
                animation-delay: 3s;
            }
        }
    }
    */