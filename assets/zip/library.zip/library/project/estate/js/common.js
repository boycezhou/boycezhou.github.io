$(function() {
    var bg = '#2099ff';
    var color = '#2099ff';
    // var bg = 'hotpink';
    // var color = 'hotpink';
    configMainColor();
    document.body.ontouchmove = function(e) {
        e.preventDefault();
    };
    /* 
     * @function 配置主题颜色
     */
    function configMainColor() {
        $('.mainBg').css('background-color', bg);
        $('.mainColor').css('color', color);
    }
});
/* 
 * @function 页面显示, 强制重载
 */
function pageshow() {
    window.addEventListener('pageshow', function(e) {
        // 通过persisted属性判断是否存在 BF Cache
        if (e.persisted) {
            location.reload();
        }
    });
}
/* 
 * @function 获取随机数
 * @return {return: String} 数字型字符串
 */
function getRandom() {
    return (+new Date()) + Math.random().toString().slice(2);
}
/* 
 * @function 对数据里的对象进行排序, 根据对象的某个属性
 * @params {data: Array} 要排序的数组(数组元素为对象)
 * @params {key: String} 对象的属性名
 * @params {flag: Boolean} 默认从小到大, true/从大到小
 */
function sortByKey(data, key, flag) {
    if (flag) {
        data.sort(compareBack_obj(key));
        return;
    }
    data.sort(compare_obj(key));
    /* 
     * @function 比较器, 从小到大
     * @params @params {key: String} 对象的属性名
     */
    function compare_obj(key) {
        return function(obj1, obj2) {
            var value1 = obj1[key];
            var value2 = obj2[key];
            if (value2 < value1) {
                return 1;
            } else if (value2 > value1) {
                return -1;
            } else {
                return 0;
            }
        }
    }
    /* 
     * @function 比较器, 从大到小
     * @params @params {key: String} 对象的属性名
     */
    function compareBack_obj(key) {
        return function(obj1, obj2) {
            var value1 = obj1[key];
            var value2 = obj2[key];
            if (value2 > value1) {
                return 1;
            } else if (value2 < value1) {
                return -1;
            } else {
                return 0;
            }
        }
    }
}
/* 
 * @function 获取字节数
 * @params {str: String} 字符串
 * @return {return: Number} 字节数
 */
function getByteLen(str) {
    var bytesCount = 0;
    var reg = /^[\u0000-\u00ff]$/;
    for (var i = 0; i < str.length; i++) {
        var c = str.charAt(i);
        if (reg.test(c)) //匹配双字节
        {
            bytesCount += 1;
        } else {
            bytesCount += 2;
        }
    }
    return bytesCount;
}
/*
 * @function 给电话号加星保密
 * @params {str: String} 字符串手机号
 * @params {frontLen: Number} 前面不加星个数
 * @params {endLen: Number} 后面不加星个数
 * @return {return: String} 加星后的字符串手机号
 */
function softTelephone(str, frontLen, endLen) {
    frontLen = frontLen || 3;
    endLen = endLen || 4;
    var len = str.length - frontLen - endLen;
    var xing = '';
    for (var i = 0; i < len; i++) {
        xing += '*';
    }
    return str.substr(0, frontLen) + xing + str.substr(str.length - endLen);
}
/*
 * @function 预览照片
 * @params {fileDom: DOM} input:type=file
 */
function imgPreview(fileDom) {
    var reader = new FileReader();
    //获取文件
    var file = fileDom.files[0];
    //读取完成
    reader.onload = function(e) {
        //获取图片dom
        var img = document.getElementsByClassName("portrait")[0];
        //图片路径设置为读取的图片
        img.src = e.target.result;
        result = e.target.result
    };
    reader.readAsDataURL(file);
}
/* 
 * @function ajax上传formData
 */
function uploadFormData(id, url) {
    var formData = new FormData();
    var file = document.getElementById(id);
    formData.append('upfile', file.files[0]);
    $.ajax({
        url: url,
        type: 'post',
        processData: false,
        contentType: false,
        data: formData,
        success: function(res) {
            console.log(url, res);
        }
    });
}
/* 
 * @function 上传照片(没有兼容性)
 */
function upload(option) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", option.url);
    xhr.overrideMimeType('text/plain; charset=x-user-defined-binary');
    // xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            if (typeof option.callback == 'function') {
                option.callback();
            }
        }
    };
    // var file = document.getElementById(id);
    // var upfile = file.files[0] ? file.files[0] : 0;
    var fd = new FormData();
    fd.append('upfile', option.upfile);
    fd.append('id', option.imgId);
    fd.append('password', option.password);
    xhr.send(fd);
}
/* 
 * @function 保留2位有效数字,并给数值每三位加 "," , 依赖 addDot和toFloat函数
 * @params {num: Number} 数值
 * @return {String} 格式化好的有效数值型字符串
 */
function formatAndDotNum2(num) {
    var num01 = toFloat(num, 2);
    var dot01 = num01 * 10 % 10;
    var dot02 = num01 * 100 % 10;
    if (dot02 > 0) {
        return addDot(num01);
    } else if (dot01 > 0) {
        return addDot(num01) + '0';
    } else {
        return addDot(num01) + '.00';
    }
}
/* 
 * @function 保留有效数字
 * @params {num: Number} 数值
 * @params {Float: Number} 有效数字个数
 * @return {Number} 格式化好的有效数值
 */
function toFloat(num, Float) {
    return +num.toFixed(Float);
}
/* 
 * @function 字符串转数字
 * @params {str: String} 要转的字符串
 */
function toDig(str) {
    return str.replace(/[^\d]/g, '');
}
/* 
 * @function 获取类型
 * @params {target: any} 要判断的值
 * @return {String} 类型
 */
function getBaseType(target) {
    const typeStr = Object.prototype.toString.call(target);
    return typeStr.slice(8, -1);
}
/* 
 * @function 获取url参数
 * @params {name: String} 参数名
 * @return {String} name参数的值
 */
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]);
    return null;
}
/* 
 * @function 获取url参数
 * @return {Object} url参数对象, key为参数名, value为参数值
 */
function GetRequest() {
    var url = location.search; //获取url中"?"符后的字串   
    var theRequest = new Object();
    if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        strs = str.split("&");
        for (var i = 0; i < strs.length; i++) {
            theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
        }
    }
    return theRequest;
}
/* 
 * @function 获取当前月的天数
 */
function mGetDate() {
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var d = new Date(year, month, 0);
    return d.getDate();
}
/* 
 * @function 给数值每三位加 ","
 * @params {num: Number} 要格式化添加","的数值
 */
function addDot(num) {
    return num.toLocaleString();
}
/*
 * @function 获取操作系统
 */
function browser() {
    var u = window.navigator.userAgent;
    return {
        android: u.indexOf("Android") > -1 || u.indexOf("Linux") > -1,
        iPhone: u.indexOf("iPhone") > -1,
        iPad: u.indexOf("iPad") > -1,
        iPod: u.indexOf("iPod") > -1
    };
}
/*
 * @function 获取可视区宽高
 * @return {return: Object} 返回一个对象
 * @return {return: Object.width} 可视区宽度
 * @return {return: Object.height} 可视区高度
 */
function getClientSize() {
    var wid = document.documentElement.clientWidth;
    var hei = document.documentElement.clientHeight;
    return {
        width: wid,
        height: hei
    }
}
/*
 * @function 将时间格式化
 * @params {format: String} 时间格式 'yyyy/MM/dd HH:mm:ss'
 * @params {date: Date} Date对象
 * @return {return: String} 格式化好的时间
 */
function format(format, date) {
    var o = {
        "M+": date.getMonth() + 1, //月份
        "d+": date.getDate(), //日
        "H+": date.getHours(), //小时
        "m+": date.getMinutes(), //分
        "s+": date.getSeconds(), //秒
        "q+": Math.floor((date.getMonth() + 3) / 3), //季度
        "f+": date.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(format))
        format = format.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(format))
            format = format.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return format;
};
/* 
 * @function 格式化时间
 * @params {date: Date} Date对象
 * @return {return: String} 格式化好的时间, '3-06 May 2018'
 */
function formatDate(date) {
    var monthEnglish = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var day = date.getDate();
    day = day < 10 ? '0' + day : day;
    var monthStr = monthEnglish[month - 1];
    var formatStr = day + ' ' + monthStr + ' ' + year;
    return formatStr;
}
/* 
 * @function 禁止页面滑动事件, 只允许.scroll盒子设置滚动
 */
function isScroller() {
    // 取消完全禁用body,touchmove事件
    document.body.ontouchmove = null;
    // //禁止body的滚动事件
    document.body.addEventListener('touchmove', function(evt) {
        if (!evt._isScroller) {
            evt.preventDefault();
        }
    });
    //给class为.scroll的元素加上自定义的滚动事件
    overscroll(document.querySelectorAll('.scroll'));
}
/* 
 * @function 禁止滚动出现黑底
 */
function overscroll(els) {
    for (var i = 0; i < els.length; ++i) {
        var el = els[i];
        el.addEventListener('touchstart', function() {
            var top = this.scrollTop,
                totalScroll = this.scrollHeight,
                currentScroll = top + this.offsetHeight;
            if (top === 0) {
                this.scrollTop = 1;
            } else if (currentScroll === totalScroll) {
                this.scrollTop = top - 1;
            }
        });
        el.addEventListener('touchmove', function(evt) {
            if (this.offsetHeight < this.scrollHeight)
                evt._isScroller = true;
        });
    }
};
/* 
 * @function 点击获取验证码
 */
function getCode() {
    var codeTimeId = null;
    var maxCodeTime = 60;
    var codeTime = maxCodeTime;
    var mainColor = $('.mainBg').css('background-color');
    // 点击获取验证码
    $('.getCode').on('tap', function() {
        if ($(this).hasClass('disabled')) {
            return;
        }
        var data = {};
        data.phone = $('#telephone').val();
        $.ajax({
            url: '/wap/broker/sendCode',
            data: data,
            type: 'post',
            dataType: 'json',
            success: function(mes) {

            }
        });
        console.log('phone', data);
        var _this = this;
        codeTime = maxCodeTime;
        $(_this)
            .addClass('disabled')
            .html('重发(' + maxCodeTime + ')');
        codeTimeId = setInterval(function() {
            codeTime--;
            if (codeTime == 0) {
                clearInterval(codeTimeId);
                $(_this)
                    .removeClass('disabled')
                    .css('background-color', mainColor)
                    .html('获取验证码');
                return;
            }
            $(_this).html('重发(' + codeTime + ')');
        }, 1000);
    });
}
/* 
 * @function 点击密码框眼镜
 */
function togglePassword() {
    $('.passwordBox .icon').on('tap', function() {
        var $password = $('#password');
        if ($password.attr('type') == 'password') {
            $password.attr('type', 'text');
        } else {
            $password.attr('type', 'password');
        }
    });
}
/* 
 * @function 点击按钮,选其一
 */
function singleChoice(mainColor) {
    var mainColor = $('.mainBg').css('background-color');
    $('.purchasingType ul').on('tap', 'li', function() {
        $(this)
            .addClass('active')
            .css('background-color', mainColor)
            .siblings()
            .removeClass('active')
            .css('background-color', '#c6c6c6');
    });
}
/* 
 * @function 验证手机号
 */
function telephoneTest() {
    var $input = $('#telephone');
    var val = $input.val();
    if (!verify.telephone(val)) {
        $('.warning').hide();
        $input.siblings('.warning').show();
        setTimeout(function() {
            $input.siblings('.warning').fadeOut(500);
        }, 1000);
        return false;
    } else {
        return true;
    }
}
/* 
 * @function 手机号事件
 */
function telephoneEvent() {
    $('#telephone').on('blur', function() {
        telephoneTest();
    });
}
/* 
 * @function 验证手机号
 */
function telephoneTest2() {
    var $input = $('#telephone');
    var $warning = $input.siblings('.warning2');
    var val = $input.val().trim();
    if (!verify.telephone(val)) {
        $warning.show();
        return false;
    } else {
        $warning.hide();
        return true;
    }
}
/* 
 * @function 手机号事件
 */
function telephoneEvent2() {
    $('#telephone').on('blur', function() {
        telephoneTest2();
    });
}
/* 
 * @function 验证邮箱
 */
function emailTest2() {
    var $input = $('#email');
    var $warning = $input.siblings('.warning2');
    var val = $input.val().trim();
    if (!verify.email(val)) {
        $warning.show();
        return false;
    } else {
        $warning.hide();
        return true;
    }
}
/* 
 * @function 邮箱事件
 */
function emailEvent2() {
    $('#email').on('blur', function() {
        emailTest2();
    });
}
/* 
 * @function 验证密码
 */
function passwordTest(password) {
    var $input = $('#password');
    var val = $input.val();
    if (!verify.password(val)) {
        $('.warning').hide();
        $input.siblings('.warning').show();
        setTimeout(function() {
            $input.siblings('.warning').fadeOut(500);
        }, 1000);
        return false;
    } else {
        return true;
    }
}
/* 
 * @function 密码事件
 */
function passwordEvent() {
    $('#password').on('blur', function() {
        passwordTest();
    });
}
/* 
 * @function 验证密码
 */
function passwordTest2() {
    var $input = $('#password');
    var $warning = $input.siblings('.warning2');
    var val = $input.val().trim();
    if (!verify.password(val)) {
        $warning.show();
        return false;
    } else {
        $warning.hide();
        return true;
    }
}
/* 
 * @function 密码事件
 */
function passwordEvent2() {
    $('#password').on('blur', function() {
        passwordTest2();
    });
}
/* 
 * @function 验证手机号
 */
function setPasswordTest() {
    var $input = $('#password');
    var val = $input.val();
    if (!verify.password(val)) {
        $('.warning').hide();
        $input.siblings('.warning').show();
        setTimeout(function() {
            $input.siblings('.warning').fadeOut(500);
        }, 1000);
        return false;
    } else {
        return true;
    }
}
/* 
 * @function 验证验证码
 */
function codeTest() {
    var $input = $('#code');
    var codeVal = $input.val();
    if (verify.empty(codeVal)) {
        $('.warning').hide();
        $input.siblings('.warning').show();
        setTimeout(function() {
            $input.siblings('.warning').fadeOut(500);
        }, 1000);
        return false;
    } else {
        return true;
    }
}
/* 
 * @function 验证码事件
 */
function codeEvent() {
    $('#code').on('blur', function() {
        codeTest();
    });
}
/* 
 * @function 验证验证码
 */
function codeTest2() {
    var $input = $('#code');
    var $warning = $input.siblings('.warning2');
    var val = $input.val().trim();
    if (verify.empty(val)) {
        $warning.show();
        return false;
    } else {
        $warning.hide();
        return true;
    }
}
/* 
 * @function 验证码事件
 */
function codeEvent2() {
    $('#code').on('blur', function() {
        codeTest2();
    });
}
/* 
 * @function 姓名验证
 */
function nameTest(code) {
    var $input = $('#name');
    var codeVal = $input.val().trim();
    if (verify.empty(codeVal)) {
        $('.warning').hide();
        $input.siblings('.warning').show();
        setTimeout(function() {
            $input.siblings('.warning').fadeOut(500);
        }, 1000);
        return false;
    } else {
        return true;
    }
}
/* 
 * @function 姓名事件
 */
function nameEvent() {
    $('#name').on('blur', function() {
        nameTest();
    });
}
/* 
 * @function 姓名验证
 */
function nameTest2(code) {
    var $input = $('#name');
    var $warning = $input.siblings('.warning2');
    var val = $input.val().trim();
    if (verify.empty(val)) {
        $warning.show();
        return false;
    } else {
        $warning.hide();
        return true;
    }
}
/* 
 * @function 姓名事件
 */
function nameEvent2() {
    $('#name').on('blur', function() {
        nameTest2();
    });
}
/* 
 * @function company名验证
 */
function companyTest(code) {
    var $input = $('#company');
    var codeVal = $input.val();
    if (verify.empty(codeVal)) {
        $('.warning').hide();
        $input.siblings('.warning').show();
        setTimeout(function() {
            $input.siblings('.warning').fadeOut(500);
        }, 1000);
        return false;
    } else {
        return true;
    }
}
/* 
 * @function 公司事件
 */
function companyEvent() {
    $('#company').on('blur', function() {
        companyTest();
    });
}
/* 
 * @function 验证公司名
 */
function companyTest2() {
    var $input = $('#company');
    var $warning = $input.siblings('.warning2');
    var val = $input.val().trim();
    if (verify.empty(val)) {
        $warning.show();
        return false;
    } else {
        $warning.hide();
        return true;
    }
}
/* 
 * @function 公司名事件
 */
function companyEvent2() {
    $('#company').on('blur', function() {
        companyTest2();
    });
}
/* 
 * @function 定位地址验证
 */
function locationTest(code) {
    var $input = $('#location');
    var codeVal = $input.val().trim();
    if (verify.empty(codeVal)) {
        $('.warning').hide();
        $input.siblings('.warning').show();
        setTimeout(function() {
            $input.siblings('.warning').fadeOut(500);
        }, 1000);
        return false;
    } else {
        return true;
    }
}
/* 
 * @function 定位地址验证
 */
function locationTest_city() {
    var $input = $('#location_city');
    var codeVal = $input.html();
    if (verify.empty(codeVal)) {
        $('.warning').hide();
        $input.siblings('.warning').show();
        setTimeout(function() {
            $input.siblings('.warning').fadeOut(500);
        }, 1000);
        return false;
    } else {
        return true;
    }
}
/* 
 * @function 年龄事件
 */
function locationEvent() {
    $('#location').on('blur', function() {
        locationTest();
    });
}
/* 
 * @function 验证定位
 */
function locationTest2() {
    var $input = $('#location');
    var $warning = $input.siblings('.warning2');
    var val = $input.val().trim();
    if (verify.empty(val)) {
        $warning.show();
        return false;
    } else {
        $warning.hide();
        return true;
    }
}
/* 
 * @function 定位地址验证
 */
function locationTest2_city() {
    var $input = $('#location_city');
    var $warning = $input.siblings('.warning2');
    var val = $input.html().trim();
    if (verify.empty(val)) {
        $warning.show();
        return false;
    } else {
        $warning.hide();
        return true;
    }
}
/* 
 * @function 定位事件
 */
function locationEvent2() {
    $('#location').on('blur', function() {
        locationTest2();
    });
}
/* 
 * @function 年龄验证
 */
function ageTest(code) {
    var $input = $('#age');
    var codeVal = $input.val();
    if (!verify.age(codeVal)) {
        $('.warning').hide();
        $input.siblings('.warning').show();
        setTimeout(function() {
            $input.siblings('.warning').fadeOut(500);
        }, 1000);
        return false;
    } else {
        return true;
    }
}
/* 
 * @function 年龄事件
 */
function ageEvent() {
    $('#age').on('blur', function() {
        ageTest();
    });
}
/* 
 * @function 验证公司名
 */
function ageTest2() {
    var $input = $('#age');
    var $warning = $input.siblings('.warning2');
    var val = $input.val().trim();
    if (verify.empty(val)) {
        $warning.show();
        return false;
    } else {
        $warning.hide();
        return true;
    }
}
/* 
 * @function 公司名事件
 */
function ageEvent2() {
    $('#age').on('blur', function() {
        ageTest2();
    });
}
/* 
 * @function 提示框
 */
function toastModel(content, callback) {
    $('#toastModel').html(content).show();
    setTimeout(function() {
        $('#toastModel').fadeOut(500);
        setTimeout(function() {
            if (typeof callback == 'function') {
                callback();
            }
        }, 500);
    }, 1000);
}