   /* 
    * @function 页面显示, 强制重载
    */
   function pageshow() {
       window.addEventListener('pageshow', function(e) {
           // 通过persisted属性判断是否存在 BF Cache
           if (e.persisted) {
               location.reload();
           }
       });
   }
   /**
    * deep clone
    * @params  {[type]} parent object 需要进行克隆的对象
    * return {[type]}        深克隆后的对象
    */
   function clone(parent) {
       // 维护两个储存循环引用的数组
       const parents = [];
       const children = [];

       const _clone = parent => {
           if (parent === null) return null;
           if (typeof parent !== 'object') return parent;

           let child, proto;

           if (isType(parent, 'Array')) {
               // 对数组做特殊处理
               child = [];
           } else if (isType(parent, 'RegExp')) {
               // 对正则对象做特殊处理
               child = new RegExp(parent.source, getRegExp(parent));
               if (parent.lastIndex) child.lastIndex = parent.lastIndex;
           } else if (isType(parent, 'Date')) {
               // 对Date对象做特殊处理
               child = new Date(parent.getTime());
           } else {
               // 处理对象原型
               proto = Object.getPrototypeOf(parent);
               // 利用Object.create切断原型链
               child = Object.create(proto);
           }

           // 处理循环引用
           const index = parents.indexOf(parent);

           if (index != -1) {
               // 如果父数组存在本对象,说明之前已经被引用过,直接返回此对象
               return children[index];
           }
           parents.push(parent);
           children.push(child);

           for (let i in parent) {
               // 递归
               child[i] = _clone(parent[i]);
           }

           return child;
       };

       function isType(obj, type) {
           if (typeof obj !== 'object') return false;
           const typeString = Object.prototype.toString.call(obj);
           let flag;
           switch (type) {
               case 'Array':
                   flag = typeString === '[object Array]';
                   break;
               case 'Date':
                   flag = typeString === '[object Date]';
                   break;
               case 'RegExp':
                   flag = typeString === '[object RegExp]';
                   break;
               default:
                   flag = false;
           }
           return flag;
       }

       function isType(re) {
           var flags = '';
           if (re.global) flags += 'g';
           if (re.ignoreCase) flags += 'i';
           if (re.multiline) flags += 'm';
           return flags;
       }
       return _clone(parent);
   };
   /* 
    * @function 将对象深克隆, 只适合符合JSON规则的对象(后台来的对象就可使用此方法)
    * @params {obj: Object} 要克隆的对象
    * {return: Object} 克隆的对象
    */
   function cloneObj(obj) {
       var str = JSON.stringify(obj);
       var newObj = JSON.parse(str);
       return newObj;
   }
   /* 
    * @function 对数据里的对象进行排序, 根据对象的某个属性
    * @params {data: Array} 要排序的数组(数组元素为对象)
    * @params {key: String} 对象的属性名
    * @params {flag: Boolean} 默认从小到大, true/从大到小
    */
   function sortByKey(data, key, flag) {
       if (flag) {
           data.sort(compareBack_obj(key));
           return;
       }
       data.sort(compare_obj(key));
       /* 
        * @function 比较器, 从小到大
        * @params @params {key: String} 对象的属性名
        */
       function compare_obj(key) {
           return function(obj1, obj2) {
               var value1 = obj1[key];
               var value2 = obj2[key];
               if (value2 < value1) {
                   return 1;
               } else if (value2 > value1) {
                   return -1;
               } else {
                   return 0;
               }
           }
       }
       /* 
        * @function 比较器, 从大到小
        * @params @params {key: String} 对象的属性名
        */
       function compareBack_obj(key) {
           return function(obj1, obj2) {
               var value1 = obj1[key];
               var value2 = obj2[key];
               if (value2 > value1) {
                   return 1;
               } else if (value2 < value1) {
                   return -1;
               } else {
                   return 0;
               }
           }
       }
   }
   /* 
    * @function 获取字节数
    * @parmas {str: String} 字符串
    * @return {return: Number} 字节数
    */
   function getByteLen(str) {
       var bytesCount = 0;
       var reg = /^[\u0000-\u00ff]$/;
       for (var i = 0; i < str.length; i++) {
           var c = str.charAt(i);
           if (reg.test(c)) //匹配双字节
           {
               bytesCount += 1;
           } else {
               bytesCount += 2;
           }
       }
       return bytesCount;
   }
   /*
    * @function 给电话号加星保密
    * @params {str: String} 字符串手机号
    * @params {frontLen: Number} 前面不加星个数
    * @params {endLen: Number} 后面不加星个数
    * @return {return: String} 加星后的字符串手机号
    */
   function softTelephone(str, frontLen, endLen) {
       frontLen = frontLen || 3;
       endLen = endLen || 4;
       var len = str.length - frontLen - endLen;
       var xing = '';
       for (var i = 0; i < len; i++) {
           xing += '*';
       }
       return str.substr(0, frontLen) + xing + str.substr(str.length - endLen);
   }
   /* 
    * @function 禁止页面滑动, 配合isScroller(), 让需要内容滚动的容器滚动
    */
   function forbidTouchmove() {
       document.body.ontouchmove = function(e) {
           e.preventDefault();
       };
   }
   /* 
    * @function获取当前月份, 日期, 小时
    */
   function getCurrentTime() {
       var date = new Date();
       var month = date.getMonth() + 1;
       var day = date.getDate();
       var hours = date.getHours();
       return {
           month: month,
           day: day,
           hours: hours
       }
   }
   /* 
    * @function 计算月供贷款额
    * @params {option: Object} 可选项
    * @params {option.price: Object} 本金
    * @params {option.month: Object} 贷款月数
    */
   function calcLoanPrice(option) {
       var price = option.price;
       var month = option.month;
       var monthRate = 0.049 / 12;
       var pay = (monthRate * Math.pow(1 + monthRate, month) * price) / (Math.pow(1 + monthRate, month) - 1);
       return parseInt(pay);
   }
   /* 
    * @function 保留有效数字, 当数字尾部为0时, 不显示   // 若要显示尾部的0, 使用 str = num.toFixed(2);
    * @parmas {num: Number} 数值
    * @parmas {Float: Number} 有效数字个数
    * @return {Number} 格式化好的有效数值
    */
   function toFloat(num, Float) {
       return +num.toFixed(Float);
   }
   /* 
    * @function 字符串转数字
    * @parmas {str: String} 要转的字符串
    */
   function toDig(str) {
       return str.replace(/[^\d]/g, '');
   }
   /* 
    * @function 获取url参数
    * @parmas {name: String} 要格式化添加","的数值
    * @return {String} name参数的值
    */
   function getQueryString(name) {
       var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
       var r = window.location.search.substr(1).match(reg);
       if (r != null) return unescape(r[2]);
       return null;
   }
   /* 
    * @function 获取url参数
    * @return {Object} url参数对象, key为参数名, value为参数值
    */
   function GetRequest() {
       var url = location.search; //获取url中"?"符后的字串   
       var theRequest = new Object();
       if (url.indexOf("?") != -1) {
           var str = url.substr(1);
           strs = str.split("&");
           for (var i = 0; i < strs.length; i++) {
               theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
           }
       }
       return theRequest;
   }
   /* 
    * @function 获取当前月的天数
    */
   function mGetDate() {
       var date = new Date();
       var year = date.getFullYear();
       var month = date.getMonth() + 1;
       var d = new Date(year, month, 0);
       return d.getDate();
   }
   /* 
    * @function 保留2位有效数字,并给数值每三位加 "," , 依赖 addDot和toFloat函数
    * @params {num: Number} 数值
    * @return {String} 格式化好的有效数值型字符串
    */
   function formatAndDotNum2(num) {
       var num01 = toFloat(num, 2);
       var dot01 = num01 * 10 % 10;
       var dot02 = num01 * 100 % 10;
       if (dot02 > 0) {
           return addDot(num01);
       } else if (dot01 > 0) {
           return addDot(num01) + '0';
       } else {
           return addDot(num01) + '.00';
       }
   }
   /* 
    * @function 给数值每三位加 "," 有兼容性
    * @parmas {num: Number} 要格式化添加","的数值
    */
   function addDot(num) {
       return num.toLocaleString();
   }
   /* 
    * @function 给数值每三位加 "," js实现, 使用: formatNum('132134'); //输出132,134.00, formatNum('132134.236'); //输出132,134.23

    * @parmas {str: String} 要格式化添加","的数值字符串
    */
   function formatNum(str) {
       var newStr = "";
       var count = 0;
       if (str.indexOf(".") == -1) {
           for (var i = str.length - 1; i >= 0; i--) {
               if (count % 3 == 0 && count != 0) {
                   newStr = str.charAt(i) + "," + newStr;
               } else {
                   newStr = str.charAt(i) + newStr;
               }
               count++;
           }
           str = newStr + ".00"; //自动补小数点后两位
           console.log(str)
       } else {
           for (var i = str.indexOf(".") - 1; i >= 0; i--) {
               if (count % 3 == 0 && count != 0) {
                   newStr = str.charAt(i) + "," + newStr;
               } else {
                   newStr = str.charAt(i) + newStr; //逐个字符相接起来
               }
               count++;
           }
           str = newStr + (str + "00").substr((str + "00").indexOf("."), 3);
           console.log(str)
       }
   }

   /*
    * @function 获取操作系统
    */
   function browser() {
       var u = window.navigator.userAgent;
       return {
           android: u.indexOf("Android") > -1 || u.indexOf("Linux") > -1,
           iPhone: u.indexOf("iPhone") > -1,
           iPad: u.indexOf("iPad") > -1,
           iPod: u.indexOf("iPod") > -1
       };
   }
   /*
    * @function 获取操作系统
    */
   function versions_browser() {
       var u = navigator.userAgent,
           app = navigator.appVersion;
       return { //移动终端浏览器版本信息   
           trident: u.indexOf('Trident') > -1, //IE内核  
           presto: u.indexOf('Presto') > -1, //opera内核  
           webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核  
           gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核  
           mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端  
           ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端  
           android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或者uc浏览器  
           iPhone: u.indexOf('iPhone') > -1, //是否为iPhone或者QQHD浏览器  
           iPad: u.indexOf('iPad') > -1, //是否iPad    
           webApp: u.indexOf('Safari') == -1, //是否web应该程序，没有头部与底部  
           weixin: u.indexOf('MicroMessenger') > -1, //是否微信   
           qq: u.match(/\sQQ/i) == " qq", //是否QQ  
           language: (navigator.browserLanguage || navigator.language).toLowerCase()
       };
   }
   /*
    * @function 获取可视区宽高
    * @return {return: Object} 返回一个对象
    * @return {return: Object.width} 可视区宽度
    * @return {return: Object.height} 可视区高度
    */
   function getClientSize() {
       var wid = document.documentElement.clientWidth;
       var hei = document.documentElement.clientHeight;
       return {
           width: wid,
           height: hei
       }
   }
   /*
    * @funtion 根据1920设计图, 设置适应当前可视区的尺寸
    */

   function size(num) {
       var designWid = 1920; // 设计图宽度尺寸
       return getClientSize().width / designWid * num;
   }

   /*
    * @function 将时间格式化
    * @params {format: String} 时间格式 'yyyy/MM/dd HH:mm:ss'
    * @params {date: Date} Date对象
    * @return {return: String} 格式化好的时间
    */
   function format(format, date) {
       var o = {
           "M+": date.getMonth() + 1, //月份
           "d+": date.getDate(), //日
           "H+": date.getHours(), //小时
           "m+": date.getMinutes(), //分
           "s+": date.getSeconds(), //秒
           "q+": Math.floor((date.getMonth() + 3) / 3), //季度
           "f+": date.getMilliseconds() //毫秒
       };
       if (/(y+)/.test(format))
           format = format.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
       for (var k in o)
           if (new RegExp("(" + k + ")").test(format))
               format = format.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
       return format;
   };
   /* 
    * @function 格式化时间
    * @params {date: Date} Date对象
    * @return {return: String} 格式化好的时间, '3-06 May 2018'
    */
   function formatDate(date) {
       var monthEnglish = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
       var year = date.getFullYear();
       var month = date.getMonth() + 1;
       var day = date.getDate();
       day = day < 10 ? '0' + day : day;
       var monthStr = monthEnglish[month - 1];
       var formatStr = day + ' ' + monthStr + ' ' + year;
       return formatStr;
   }

   function isScroller() {
       // 取消完全禁用body,touchmove事件
       document.body.ontouchmove = null;
       // //禁止body的滚动事件
       document.body.addEventListener('touchmove', function(evt) {
           if (!evt._isScroller) {
               evt.preventDefault();
           }
       });
       //给class为.scroll的元素加上自定义的滚动事件
       overscroll(document.querySelectorAll('.scroll'));
   }
   /* 
    * @function 禁止滚动出现黑底
    */
   function overscroll(els) {
       for (var i = 0; i < els.length; ++i) {
           var el = els[i];
           el.addEventListener('touchstart', function() {
               var top = this.scrollTop,
                   totalScroll = this.scrollHeight,
                   currentScroll = top + this.offsetHeight;
               if (top === 0) {
                   this.scrollTop = 1;
               } else if (currentScroll === totalScroll) {
                   this.scrollTop = top - 1;
               }
           });
           el.addEventListener('touchmove', function(evt) {
               if (this.offsetHeight < this.scrollHeight)
                   evt._isScroller = true;
           });
       }
   };

   /*
    * @function: 随机生成字符串
    * @params {len: Number} 随机字符的长度
    * @return {return: String} 随机字符
    */
   function randomString(len) {　　
       len = len || 32;　　
       var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678'; /****默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1****/ 　　
       var maxPos = $chars.length;　　
       var pwd = '';　　
       for (i = 0; i < len; i++) {　　　　
           pwd += $chars.charAt(Math.floor(Math.random() * maxPos));　　
       }　　
       return pwd;
   }
   /*
    * @function 16进制颜色值转为rgba颜色值
    * @params {color: String} 16进制颜色值
    * @return {return: String} rgba颜色值
    */
   function hexToRgba(color) {
       var str = color.charAt(0) == "#" ? color.substring(1, 7) : color;
       var r = parseInt(str.substring(0, 2), 16);
       var g = parseInt(str.substring(2, 4), 16);
       var b = parseInt(str.substring(4, 6), 16);
       var alpha = 0.5;
       return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
   }
   /* 
    * @function 16进制验证
    * @params {str: String} 16进制颜色值
    * @return {return: String} / {return: -1} 返回-1为验证不通过, 验证通过返回传入值
    */
   function regHex(str) {
       var reg = /^#?([0-9a-fA-F]{6}|[0-9a-fA-F]{3})$/;
       var regFlag = reg.test(str);
       if (regFlag) {
           str = str.charAt(0) == '#' ? str : '#' + str;
           return str;
       } else {
           return -1;
       }
   }
   /*
    * @function 预览照片, 此处预览照片img.className = 'portrait', html: <img class="portrait" src="" alt=""><input id="imgFile" type="file" name="upfile" multiple accept="image/png, image/jpeg, image/gif, image/jpg" style="display:none" />
    * @params {fileDom: DOM} input:type=file
    */
   function imgPreview(fileDom) {
       var reader = new FileReader();
       //获取文件
       var file = fileDom.files[0];
       //读取完成
       reader.onload = function(e) {
           //获取图片dom
           var img = document.getElementsByClassName("portrait")[0];
           //图片路径设置为读取的图片
           img.src = e.target.result;
           result = e.target.result
       };
       reader.readAsDataURL(file);
   }
   /* 
    * @function 上传照片(没有兼容性), html(multiple capture="camera"): <input id="imgFile" type="file" name="upfile" multiple accept="image/png, image/jpeg, image/gif, image/jpg" style="display:none" /> 
    */
   function upload() {
       var xhr = new XMLHttpRequest();
       xhr.open("POST", "uploads");
       xhr.overrideMimeType('text/plain; charset=x-user-defined-binary');
       // xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
       xhr.onreadystatechange = function() {
           if (xhr.readyState == 4 && xhr.status == 200) {

           }
       };
       var file = document.getElementById("imgFile");
       var fd = new FormData();
       fd.append('upfile', file.files[0]);
       xhr.send(fd);
   }
   /* 
    * @function ajax上传formData, html:  #file: input:type=file
    */
   function uploadFormData02() {
       var formData = new FormData();
       formData.append('file', $('#file')[0].files[0]);
       $.ajax({
           url: 'http://example.com/api',
           method: 'post',
           processData: false,
           contentType: false,
           data: formdata
       });
   }
   /* 
    * @function ajax上传formData
    */
   function uploadFormData(selector, url) {
       var formData = new FormData();
       formData.append('file', $(selector)[0].files[0]);
       $.ajax({
           url: url,
           type: 'post',
           processData: false,
           contentType: false,
           data: formData,
           success: function(res) {
               console.log(url, res);
           }
       });
   }