'use strict';
/* 
 * @function 为字母创建字谜
 * @params {str: String} 字符串
 * @return {return: Array} anagrams('abc') -> ['abc','acb','bac','bca','cab','cba']
 */
function anagrams(str) {
    if (str.length <= 2) return str.length === 2 ? [str, str[1] + str[0]] : [str];
    return str.split('').reduce((acc, letter, i) =>
        acc.concat(anagrams(str.slice(0, i) + str.slice(i + 1)).map(val => letter + val)), []);
}
// const anagrams = str => {
//     if (str.length <= 2) return str.length === 2 ? [str, str[1] + str[0]] : [str];
//     return str.split('').reduce((acc, letter, i) =>
//         acc.concat(anagrams(str.slice(0, i) + str.slice(i + 1)).map(val => letter + val)), []);
// };
/* 
 * @function 求数组平均值
 * @params {arr: Array} 数组
 * @return {return: Number} 数组平均值
 */
const average = arr => arr.reduce((acc, val) => acc + val, 0) / arr.length;
/* 
 * @function 大写每个单词的首字母
 * @params {str: String} 字符串
 * @return {return: String} 每个单词的首字母大写的字符串
 */
const capitalizeEveryWord = str => str.replace(/\b[a-z]/g, char => char.toUpperCase());
/* 
 * @function 首字母大写
 * @params {str: String} 字符串
 * @params {lowerRest: Boolean} false(默认)/保持字符串其余部分不变, true/字符串其余部分转换为小写
 * @return {return: String} 首字母大写的字符串
 */
const capitalize = (str, lowerRest = false) => str.slice(0, 1).toUpperCase() + (lowerRest ? str.slice(1).toLowerCase() : str.slice(1));
/* 
 * @function 检查回文
 * @params {str: String} 字符串
 * @return {return: Boolean} false/不是回文, true/回文
 */
const palindrome = str => {
    const s = str.toLowerCase().replace(/[\W_]/g, '');
    return s === s.split('').reverse().join('');
};
/* 
 * @function 计数数组中值的出现次数
 * @params {arr: Array} 数组
 * @params {value: any} 基本数据类型值
 * @return {return: Number} 值出现次数
 */
const countOccurrences = (arr, value) => arr.reduce((a, v) => v === value ? a + 1 : a + 0, 0);
/* 
 * @function 获取所有不是数组的元素, deepFlatten([1,[2],[[3],4],5]) -> [1,2,3,4,5]
 * @params {arr: Array} 数组
 * @return {return: Array} 值出现次数
 */
const deepFlatten = arr => arr.reduce((a, v) => a.concat(Array.isArray(v) ? deepFlatten(v) : v), []);
/* 
 * @function 扁平数组,只能扁平一层 flatten([1,[2],3,4]) -> [1,2,3,4]
 * @params {arr: Array} 数组
 * @return {return: Array} 值不重复的数组
 */
const flatten = arr => arr.reduce((a, v) => a.concat(v), []);
/* 
 * @function 数组之间的区别, difference([1,2,3], [1,2]) -> [3]
 * @params {a: Array} 数组
 * @params {b: Array} 数组
 * @return {return: Array} 数组中不同的值
 */
const difference = (a, b) => {
    const s = new Set(b);
    return a.filter(x => !s.has(x));
};
/* 
 * @function 数组之间的相似性, similarity([1,2,3], [1,2,4]) -> [1,2]
 * @params {arr: Array} 数组
 * @params {values: Array} 数组
 * @return {return: Array} 数组中相同的值
 */
const similarity = (arr, values) => arr.filter(v => values.includes(v));
/* 
 * @function 转义正则表达式
 * @params {str: String} 字符串
 * @return {return: String} 转义好的字符串
 */
const escapeRegExp = str => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
/* 
 * @function 阶乘
 * @params {n: Number} 阶乘数
 * @return {return: Number} 阶乘结果
 */
const factorial = n => n <= 1 ? 1 : n * factorial(n - 1);
/* 
 * @function 斐波那契数组生成器
 * @params {n: Number} 阶乘数
 * @return {return: Array} 斐波那契数组
 */
const fibonacci = n => Array(n).fill(0).reduce((acc, val, i) => acc.concat(i > 1 ? acc[i - 1] + acc[i - 2] : i), []);
/* 
 * @function 过滤数组中的非唯一值, 去重
 * @params {arr: Array} 数组
 * @return {return: Array} 值不重复的数组
 */
const filterNonUnique = arr => arr.filter(i => arr.indexOf(i) === arr.lastIndexOf(i));
/* 
 * @function 过滤数组中的非唯一值, 去重
 * @params {arr: Array} 数组
 * @return {return: Array} 值不重复的数组
 */
const unique = arr => [...new Set(arr)];
/* 
 * @function 最大公约数（GCD）
 * @params {x: Number} 数组
 * @params {y: Number} 数组
 * @return {return: Number} 最大公约数
 */
const gcd = (x, y) => !y ? x : gcd(y, x % y);
/* 
 * @function 测试功能所花费的时间
 * @params {callback: Function} 功能函数
 * @return {return: Number} 功能函数返回值
 */
const timeTaken = callback => {
    console.time('timeTaken');
    const r = callback();
    console.timeEnd('timeTaken');
    return r;
};
/* 
 * @function 使数组组合成包含所有组合的数组
 * @params {arr: Array} 功能函数
 * @return {return: Array} 包含所有组合的数组
 */
const powerset = arr => {
    arr.reduce((a, v) => a.concat(a.map(r => [v].concat(r))), [
        []
    ]);
};
/* 
 * @function 范围内的随机整数
 * @params {min: Number} 最小值
 * @params {max: Number} 最大值
 * @return {return: Number} 随机整值
 */
const randomIntegerInRange = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
/* 
 * @function 随机化数组的顺序
 * @params {arr: Array} 数组
 * @return {return: Array} 顺序随机后的数组
 */
const shuffle = arr => arr.sort(() => Math.random() - 0.5);
/* 
 * @function 随机化数组的顺序, 方法2
 * @params {arr: Array} 数组
 * @return {return: Array} 顺序随机后的数组
 */
const shuffle2 = arr => {
        let r = arr.map(Math.random);
        return arr.sort((a, b) => r[a] - r[b]);
    }
    /* 
     * @function 重定向到URL
     */
const redirect = (url, asLink = true) => asLink ? window.location.href = url : window.location.replace(url);
/* 
 * @function 反转一个字符串
 * @params {str: String} 字符串
 * @return {return: String} 反转后的字符串
 */
const reverseString = str => [...str].reverse().join('');
/* 
 * @function RGB到十六进制
 * @params {r: Number} R
 * @params {g: Number} G
 * @params {b: Number} B
 * @return {return: String} 十六进制
 */
const rgbToHex = (r, g, b) => ((r << 16) + (g << 8) + b).toString(16).padStart(6, '0');
/* 
 * @function 滚动到顶部
 */
const scrollToTop = _ => {
    const c = document.documentElement.scrollTop || document.body.scrollTop;
    if (c > 0) {
        window.requestAnimationFrame(scrollToTop);
        window.scrollTo(0, c - c / 8);
    }
};
/* 
 * @function 按字符串排序（按字母顺序排列）
 * @params {str: String} 字符串
 * @return {return: String} 排序后的字符串
 */
const sortCharactersInString = str => str.split('').sort((a, b) => a.localeCompare(b)).join('');
/* 
 * @function 数组总和
 * @params {arr: Array} 数组
 * @return {return: Number} 数组总和
 */
const sum = arr => arr.reduce((acc, val) => acc + val, 0);
/* 
 * @function URL参数
 * @params {url: String} 地址
 * @return {return: Object} 参数对象
 */
const getUrlParameters = url => {
    url.match(/([^?=&]+)(=([^&]*))/g).reduce(
        (a, v) => (a[v.slice(0, v.indexOf('='))] = v.slice(v.indexOf('=') + 1), a), {}
    );
};
/* 
 * @function 验证数字
 * @params {n: Number} 数字
 * @return {return: Boolean} 
 */
const validateNumber = n => !isNaN(parseFloat(n)) && isFinite(n) && Number(n) == n;