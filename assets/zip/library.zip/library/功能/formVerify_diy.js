function Verify() {

};

Verify.prototype = {
    /* 
     * @function 手机号码验证
     * @params {str: String} 用户在表单中输入的值
     * @return {Boolean} true/格式正确 false/格式不正确
     */
    telephone: function(str) {
        var reg = /^1[0-9]{10}$/;
        return reg.test(str.trim());
    },
    /* 
     * @function 密码验证(6位任意字符)
     * @params {str: String} 用户在表单中输入的值
     * @return {Boolean} true/格式正确 false/格式不正确
     */
    password: function(str) {
        var reg = /^.{6}$/;
        return reg.test(str.trim());
    },
    /* 
     * @function 验证输入框为不为空(空格不算字符)
     * @params {str: String} 用户在表单中输入的值
     * @return {Boolean} true/空 false/不为空
     */
    empty: function(str) {
        return !str.trim().length;
    }
}

window.verify = new Verify();